<?php include AS_THEME."as_header.php" ?>
<div id="body">
		<div>
			<div>
				<div>
					<div>
						<h1>Welcome</h1><hr>
				</div>
				</div>
			</div>
		</div>
	</div>
 <?php include AS_THEME."as_footer.php" ?>
  
