<?php include AS_THEME."as_header.php" ?>
	<div id="site_content">	

	  <div id="content"> 
        
		
        <div class="content_item">
		  <br>
		   <h1>Complaint Submitted</h1>
		   <p>Thank you for taking time to submitt a complaint here. Our experts will get back to you as soon as possible via the email you have provided in the complaint!.
		</div>
      </div>   
	</div><!--close site_content-->  	
  </div><!--close main-->
  <?php include AS_THEME."as_footer.php" ?>