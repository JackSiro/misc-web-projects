			<div id="footer"><div><div>
              <?php echo as_get_option('sitename') ?>
			  <!--Powered by <a href="#">##</a>-->
          </div></div></div><!-- end footer -->
      </div><!-- end body -->
  </div><!-- end wrapper -->
</body>
</html>