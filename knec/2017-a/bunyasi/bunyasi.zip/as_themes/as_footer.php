		</div>
		<div id="footer">
			<ul class="connect">
				<li>
					<a href="http://www.freewebsitetemplates.com/go/twitter/" class="twitter"></a>
				</li>
				<li>
					<a href="http://www.freewebsitetemplates.com/go/facebook/" class="facebook"></a>
				</li>
				<li>
					<a href="http://www.freewebsitetemplates.com/go/googleplus/" class="googleplus"></a>
				</li>
			</ul>
			<span class="footnote"> &copy; Copyright 2017. <?php echo as_get_option('sitename') ?> All rights reserved. </span> </div>
	</div>
</body>
</html>