<?php include AS_THEME."as_header.php";
	$database = new As_Dbconn();
	$movieid = $_GET['as_movieid'];
	$as_db_query = "SELECT * FROM as_movie WHERE movieid=$movieid";
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $movieid, $movie_type, $movie_title, $movie_language, $movie_price, $movie_description, $movie_year) = $database->get_row( $as_db_query );
	}
?>
	<h2>MOVIE:  <?php echo $movie_title ?></h2>
	<div id="contact_form">
		<table class="view_tb">
			<tr>
				<td valign="top" rowspan="6"><img src="as_media/movie.png" style="border-radius:5px;"/></td>
				<td>TYPE </td><td>:<?php echo $movie_type ?></td></tr>
			<tr><td>LANGUAGE </td><td>:<?php echo $movie_language ?></td></tr>
			<tr><td>PRICE </td><td>: KES. <?php echo $movie_price ?>.00</td></tr>
			<tr><td>YEAR </td><td>:<?php echo $movie_year ?></td></tr>
			<tr><td valign="top">DESCRIPTION </td><td valign="top"><p>: <?php echo $movie_description ?></p></td></tr>
			<tr><td valign="top">ACTIONS </td><td valign="top">
				<a href="index.php?page=movie_edit&amp;as_movieid=<?php echo $movieid ?>">Edit Movie</a> | <a href="index.php?page=movie_delete&amp;as_movieid=<?php echo $movieid ?>" onclick="return confirm('Are you sure you want to delete this item from the system? \nBe careful, this page can not be reversed.')">Delete Movie?</a>
			</td></tr>
		</table>
		<div class="cleaner h40"></div>
	</div>
<?php include AS_THEME."as_footer.php" ?>