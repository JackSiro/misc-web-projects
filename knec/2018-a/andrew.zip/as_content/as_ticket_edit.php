<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	$database = new As_Dbconn();			

	$ticketid = $results['item'];
	$as_db_query = "SELECT * FROM as_ticket WHERE ticketid = '$ticketid'";
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $ticketid, $ticket_customer,$ticket_mobile, $ticket_date, $ticket_type, $ticket_stand, $ticket_booking, $ticket_amount, $ticket_payment) = $database->get_row( $as_db_query );
	}
?>
  <h4><strong>Edit</strong><em>A Ticket Now!!!</em></h4><hr>
		<form method="post" action="index.php?action=ticket_edit&&as_ticketid=<?php echo $ticketid ?>" enctype="multipart/form-data" >
                <label>Customer Name:
				<input type="text" class="input_field" autocomplete="off" name="customer" value="<?php echo $ticket_customer ?>" required >
				
				</label>Mobile Number:</label>
				<input type="text" class="input_field" autocomplete="off" name="mobile" value="<?php echo $ticket_mobile ?>" required />
					
				<label>Ticket Date:</label>
				<input type="text" class="input_field" autocomplete="off" name="date" value="<?php echo $ticket_date ?>" required >
				
				<label>Ticket Type:</label>
				<select name="type" class="input_field" required >
					<option value="<?php echo $ticket_type ?>" > - Ticket Type - </option>
					<option value="VIP" > VIP Class </option>
					<option value="Normal" > Normal </option>
				</select>
					
				<label>Stand Type:</label>
				<select name="stand" class="input_field" required >
					<option value="<?php echo $ticket_stand ?>" > - Stand Type - </option>
					<option value="VIP" > VIP Class </option>
					<option value="Normal" > Normal </option>
				</select>
				
				<label>Booking Type:</label>
				<select name="booking" class="input_field" required >
					<option value="<?php echo $ticket_type ?>" > - Booking Type - </option>
					<option value="Advance" > Advance Booking </option>
					<option value="Normal" > Normal Booking </option>
				</select>
				
                <label>Amount Paid:</label>
				<input type="text" class="input_field" autocomplete="off" name="amount" value="<?php echo $ticket_amount ?>" required >
				
				<label>Mode of Payment:</label>
				<select name="payment" class="input_field" required >
					<option  value="<?php echo $ticket_payment ?>" > - Mode of payment - </option>
					<option value="Cash payment"> Cash payment </option>
					<option value="Mpesa/AirtelMoney"> Mpesa/AirtelMoney </option>
					<option value="Cheque"> Cheque </option>
					<option value="Visa Card"> Visa Card </option>
				</select>
					
				<input type="submit" class="input_field" name="EditTicket" value="Save Changes">
				</form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>