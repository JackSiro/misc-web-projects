<?php
	session_start();
	require( 'as_config.php' );
	include AS_FUNC.'as_dbconn.php';
	require AS_FUNC.'as_base.php';
	include AS_FUNC.'as_options.php';
	include AS_FUNC.'as_paging.php';
	include AS_FUNC.'as_posting.php';
	include AS_FUNC.'as_employees.php';
 	
 	$as_loginid = isset( $_SESSION['tickets_user'] ) ? $_SESSION['tickets_user'] : "";
	
	$page = isset( $_GET['page'] ) ? $_GET['page'] : "";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	
if ( $page != "login" && $page != "logout" && $page != "register" 
			&& $page != "forgot_password" && $page != "recover_password"
			&& $page != "forgot_username" && $page != "recover_username"
			&& $page != "logout" && !$as_loginid ) {
			as_signin();
	   exit;
	} 
    
  switch ( $page ) {
	case 'login': as_signin();
		break;
	case 'register': register();
		break;
	case 'forgot_password': forgot_password();
		break;
	case 'recover_password': recover_password();
		break;
	case 'forgot_username': forgot_username();
		break;
	case 'recover_username': recover_username();
		break;
	case 'logout': logout();
		break;
	case 'book_now':  ticket_new();
		break;
	case 'ticket_all': ticket_all();
		break;
	case 'ticket_view': ticket_view();
		break;
	case 'ticket_edit':  ticket_edit();
		break;
	case 'ticket_delete':  ticket_delete();
		break;
	case 'movie_all': movie_all();
		break;
	case 'movie_new': movie_new();
		break;
	case 'movie_view': movie_view();
		break;
	case 'movie_edit':  movie_edit();
		break;
	case 'movie_delete':  movie_delete();
		break;
	case 'employee_all': employee_all();
		break;
	case 'employee_new':  employee_new();
		break;
	case 'employee_view': employee_view();
		break;
	case 'profile': 
		if ($myaccount) as_profile();
		break;
	case 'options':  as_options();
		break; 
	case 'booking':  as_booking();
		break;	
    default:
		as_booking();
}

function as_booking() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Dashboard"; 
	
	if ( isset( $_POST['BookNow'] ) ) {		
		as_add_new_ticket();	
		header( "Location: index.php?page=ticket_all");						
	}  else {	
		require( "as_homepage.php" );
	}
}

function as_options() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Options"; 
	$as_loginid = isset( $_SESSION['tickets_user'] ) ? $_SESSION['tickets_user'] : "";
	
	if ( isset( $_POST['SaveSite'] ) ) {
			
		as_set_option('sitename', $_POST['sitename'], $as_loginid);	
		as_set_option('keywords', $_POST['keywords'], $as_loginid);
		as_set_option('description', $_POST['description'], $as_loginid);
		as_set_option('siteurl', $_POST['siteurl'], $as_loginid);
		
		header( "Location: index.php?page=options");						
	}  else if ( isset( $_POST['CancelSave'] ) ) {
		header( "Location: index.php?page=options");						
	}  else {
		require( "as_options.php" );
	}
	
}

	
function employee_all() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Users";  
	require( "as_employee_all.php" );
}

function employee_new() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Newuser"; 
	
	if ( isset( $_POST['AddEmployee'])) {
		as_add_new_user();
		header( "Location: index.php?page=employee_new");						
	}  else if ( isset( $_POST['AddClose'])) {
		as_add_new_user();
		header( "Location: index.php?page=employee_all");						
	}  else {
		require( "as_employee_new.php" );
	}	
	
}
function employee_view() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Viewuser"; 
	$as_employeeid = isset( $_GET['as_employeeid'] ) ? $_GET['as_employeeid'] : "";
	
	$as_db_query = "SELECT * FROM as_employee WHERE employeeid = '$as_employeeid'";
	$database = new As_Dbconn();
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $employeeid, $employee_name) = $database->get_row( $as_db_query );
		$results['user'] = $employeeid;
	} else  {
		return false;
		header( "Location: index.php?page=employee_all");	
	}
	
	require( "as_employee_view.php" );
		
}

function profile() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Profile"; 
	$as_employeename = $_SESSION['tickets_user'];
	
	$as_db_query = "SELECT * FROM as_employee WHERE employee_name = '$as_employeename'";
	$database = new As_Dbconn();
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $employeeid, $employee_name) = $database->get_row( $as_db_query );
		$results['user'] = $employeeid;
	} else  {
		return false;
		header( "Location: index.php?page=users");	
	}
	
	require( "as_viewuser.php" );
		
}

	
function register() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Register"; 
	
	if ( isset( $_POST['Register'] ) ) {
		as_register_me();
		header( "Location: index.php");		
	}  else {
		require( "as_employee_register.php" );
	}	
	
}

  function forgot_username() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "ForgotUsername"; 
	
	if ( isset( $_POST['ForgotUsername'] ) ) {
		$email = $_POST['username'];
		$password = md5($_POST['password']);
		as_recover_username($email, $password);
		header( "Location: index.php?action=recovered_username");		
	}  else {
		require( "as_forgot_username.php" );
	}	
}

  function forgot_password() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "ForgotPassword"; 
	
	if ( isset( $_POST['ForgotPassword'] ) ) {
		$username = $_POST['username'];
		$email = $_POST['email'];
		as_recover_password($username, $email);
		header( "Location: index.php?action=recover_password");		
	}  else {
		require( "as_forgot_password.php" );
	}	
	
}

function recover_username() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "RecoveredUsername"; 
	require( "as_recover_username.php" );
	
}

function recover_password() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "RecoveredPassword"; 
	
	if ( isset( $_POST['RecoverPassword'] ) ) {
		$username = $_POST['username'];
		$password = md5($_POST['passwordcon']);
		as_change_password($username);
		header( "Location: index.php");		
	}  else {
		require( "as_recover_password.php" );
	}
}

function ticket_all() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "All Company Items"; 
	
	if ( isset( $_POST['SearchThis'])) {
		$as_search = $_POST['as_search'];
		$as_catid = $_POST['as_catid'];
		
		header( "Location: index.php?page=as_search&&as_search=".$as_search."&&as_catid=".$as_catid);
								
	}  else {	
		require( "as_ticket_all.php" );
	}
}

function ticket_search() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Search"; 
	$results['search'] = isset( $_GET['as_ticketid'] ) ? $_GET['as_ticketid'] : "";
	$results['searchcat'] = isset( $_GET['as_catid'] ) ? $_GET['as_catid'] : "";
	
	if ( isset( $_POST['SearchThis'])) {
		$as_search = $_POST['as_search'];
		$as_catid = $_POST['as_catid'];
		
		header( "Location: index.php?page=as_search&&as_search=".$as_search."&&as_catid=".$as_catid);
														
	}  else {	
		require( "as_search.php" );
	}
}
function ticket_new() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Newticket"; 
	
	if ( isset( $_POST['Finish'])) {
		as_add_new_ticket();	
		header( "Location: index.php?page=ticket_all");						
	} else if ( isset( $_POST['Cancel'])) {
		header( "Location: index.php?page=ticket_all");						
	} else {
		require( "as_ticket_new.php" );
	}	
	
}

function ticket_view() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Viewitem"; 
	$as_ticketid = isset( $_GET['as_ticketid'] ) ? $_GET['as_ticketid'] : "";
	
	$as_db_query = "SELECT * FROM as_ticket WHERE ticketid = '$as_ticketid'";
	$database = new As_Dbconn();
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $ticketid, $employee_name) = $database->get_row( $as_db_query );
		$results['item'] = $ticketid;
	} else  {
		return false;
		header( "Location: index.php?page=ticket_all");	
	}
	
	if ( isset( $_POST['OrderNow'])) {
		as_add_new_order();
		header( "Location: index.php?page=order_all");				
	}  else {
		require( "as_ticket_view.php" );
	}	
	
}

function ticket_edit() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Edititem"; 
	$as_ticketid = isset( $_GET['as_ticketid'] ) ? $_GET['as_ticketid'] : "";
	
	$as_db_query = "SELECT * FROM as_ticket WHERE ticketid = '$as_ticketid'";
	$database = new As_Dbconn();
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $ticketid) = $database->get_row( $as_db_query );
		$results['item'] = $ticketid;
	} else  {
		return false;
		header( "Location: index.php?page=elibrary");	
	}
	
	if ( isset( $_POST['EditTicket'])) {
		as_edit_ticket($as_ticketid);
		header( "Location: index.php?page=ticket_view&&as_ticketid=".$as_ticketid);					
	}  else {
		require( "as_ticket_edit.php" );
	}	
	
}

function ticket_delete() {
	$as_ticketid = isset( $_GET['as_ticketid'] ) ? $_GET['as_ticketid'] : "";
	
	$database = new As_Dbconn();
	$as_db_query = "DELETE * FROM as_ticket WHERE ticketid = '$as_ticketid'";
	$delete = array(
		'ticketid' => $as_ticketid,
	);
	$deleted = $database->delete( 'as_ticket', $delete, 1 );
	if( $deleted )	{
		header( "Location: index.php?page=ticket_all");	
	}
}

function movie_all() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "All Company Items"; 
	
	if ( isset( $_POST['SearchThis'])) {
		$as_search = $_POST['as_search'];
		$as_catid = $_POST['as_catid'];
		
		header( "Location: index.php?page=as_search&&as_search=".$as_search."&&as_catid=".$as_catid);
								
	}  else {	
		require( "as_movie_all.php" );
	}
}

function movie_search() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Search"; 
	$results['search'] = isset( $_GET['as_movieid'] ) ? $_GET['as_movieid'] : "";
	$results['searchcat'] = isset( $_GET['as_catid'] ) ? $_GET['as_catid'] : "";
	
	if ( isset( $_POST['SearchThis'])) {
		$as_search = $_POST['as_search'];
		$as_catid = $_POST['as_catid'];
		
		header( "Location: index.php?page=as_search&&as_search=".$as_search."&&as_catid=".$as_catid);
														
	}  else {	
		require( "as_search.php" );
	}
}
function movie_new() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Newmovie"; 
	
	if ( isset( $_POST['SaveMovie'])) {
		as_add_new_movie();	
		header( "Location: index.php?page=movie_all");						
	} else {
		require( "as_movie_new.php" );
	}	
	
}

function movie_view() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Viewitem"; 
	$as_movieid = isset( $_GET['as_movieid'] ) ? $_GET['as_movieid'] : "";
	require( "as_movie_view.php" );
}

function movie_edit() {
	$results = array();
	$results['pageTitle'] = "Gates Ticketing System";
	$results['pageAction'] = "Edititem"; 
	$as_movieid = isset( $_GET['as_movieid'] ) ? $_GET['as_movieid'] : "";
	
	if ( isset( $_POST['UpdateMovie'])) {
		as_edit_movie($as_movieid);
		header( "Location: index.php?page=movie_view&&as_movieid=".$as_movieid);					
	}  else {
		require( "as_movie_edit.php" );
	}
}

function movie_delete() {
	$as_movieid = isset( $_GET['as_movieid'] ) ? $_GET['as_movieid'] : "";
	
	$database = new As_Dbconn();
	$as_db_query = "DELETE * FROM as_movie WHERE movieid = '$as_movieid'";
	$delete = array(
		'movieid' => $as_movieid,
	);
	$deleted = $database->delete( 'as_movie', $delete, 1 );
	if( $deleted )	{
		header( "Location: index.php?page=movie_all");	
	}
}
