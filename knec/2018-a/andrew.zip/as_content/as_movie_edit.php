<?php include AS_THEME."as_header.php";
	$database = new As_Dbconn();
	$movieid = $_GET['as_movieid'];
	$as_db_query = "SELECT * FROM as_movie WHERE movieid=$movieid";
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $movieid, $movie_type, $movie_title, $movie_language, $movie_price, $movie_description, $movie_year) = $database->get_row( $as_db_query );
	}
?>
	<h2>Edit a Movie</h2>
	<div id="contact_form">
		<form method="post" action="index.php?page=movie_edit&amp;as_movieid=<?php echo $movieid ?>" >
		<label>Movie Type:</label>
		<select name="movie_type" class="input_field" required>
			<option></option>
			<option value="Horror">Horror</option>
			<option value="Fiction">Fiction</option>
			<option value="Action">Action</option>
			<option value="Romance">Romance</option>
		</select>
		
		<label>Movie Title:</label>
		<input type="text" class="input_field" autocomplete="off" name="movie_title" value="<?php echo $movie_title ?>" required />
		
		<label>Language:</label>
		<select name="movie_language" class="input_field" required>
			<option></option>
			<option value="English">English</option>
			<option value="Kiswahili">Kiswahili</option>
			<option value="French">French</option>
			<option value="Spanish">Spanish</option>
		</select>
	
		<label>Movie Price:</label>
		<input type="number" class="input_field" autocomplete="off" name="movie_price" value="<?php echo $movie_price ?>" required />
		
		<label>Movie Year:</label>
		<input type="number" class="input_field" autocomplete="off" name="movie_year" value="<?php echo $movie_year ?>" required />
		
		<label>Description:</label>
		<textarea class="input_field" name="movie_description" required><?php echo $movie_description ?></textarea>
							
		<div class="cleaner"></div>
			<input type="submit" name="UpdateMovie" value="Update Movie" class="submit_btn" />
		</form>
		<div class="cleaner h40"></div>
	</div>
<?php include AS_THEME."as_footer.php" ?>