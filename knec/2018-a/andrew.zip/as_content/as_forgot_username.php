<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	?>
  <h4><strong>Username</strong> <em>Recovery Center</em></h4>
				
				<hr>
				<p>Sorry for Loosing your username. Fill in the form below to get assistance on recovering your username.</p><br>
				<form action="index.php?page=forgot_username" method="post" >
			
				<tr>
					<td>Enter your email (*)</td>
					<td><input type="text" name="username" id="username" autocomplete="off" required autofocus  /></td>
				</tr>
				<tr><td>Enter your password (*)</td>
			</td><td>
			<input type="password" name="password" id="password" autocomplete="off" required maxlength="20" />
			</td></tr>
			</table>
			<input type="submit" id="aalogin-button" name="ForgotUsername" value="Forgot Username" />
        
      </form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>