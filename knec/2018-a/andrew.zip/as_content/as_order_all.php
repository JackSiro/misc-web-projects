<?php include AS_THEME."as_header.php";
	$database = new As_Dbconn();			
	
	$as_db_query = "SELECT * FROM as_order ORDER BY orderid DESC LIMIT 20";
	$results = $database->get_results( $as_db_query );
?>
 
        <div class="cleaner h20"></div>
		  <h2><?php echo $database->as_num_rows( $as_db_query ) ?> Order Items </h2> 
          <br><hr><br>
			<div class="main_content" align="center">
			   <table class="tt_tb">
				<thead><tr class="tt_tr">
				  <th style="width:70px;"></th>
				  <th>Order</th>
				  <th>Cost</th>
				  <th>Buyer</th>
				  <th>Ordered on</th>
				  <th></th>
				</tr></thead>
				<tbody>
                <?php foreach( $results as $row ) { ?>
		        <tr onclick="location='index.php?page=order_view&amp;as_orderid=<?php echo $row['orderid'] ?>'">
					<td><img class="iconic" src="as_media/order_default.jpg" /></label>
				<?php echo $row['order_qty']." ".$row['order_title'] ?></label>
				<?php echo $row['order_price'] ?>/=</label>
				<?php echo $row['order_fullname'] ?><br>
					<?php echo $row['order_mobile'] ?><br>
					<?php echo $row['order_email'] ?><br>
					<?php echo $row['order_address'] ?></label>
				<?php echo date("j/m/y", strtotime($row['order_created'])); ?></label>
				</td>
		        </tr>
			
			<?php } ?>
			
                      </tbody>
                    </table>
					
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>