<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	?>
  <h4><strong>Password</strong> <em>Recovery Center</em></h4>
				
				<hr>
				<p>Reset Your Password.</p><br>
				<form action="index.php?page=recover_password" method="post" >
			<input type="hidden" name="username" value="<?php echo $_SESSION['recover_password'] ?>" />
			
				<label>New Password (*required)</label>
				<input type="password" name="password" id="password" autocomplete="off" required autofocus  maxlength="20"/>

				<tr><td>Confirm Password (*required)</td>
			<td>
			<input type="password" name="passwordcon" id="passwordcon" autocomplete="off" required autofocus maxlength="20" />
			</td></tr>
			</table>
			<input type="submit" id="aalogin-button" name="RecoverPassword" value="Reset Password" />
        
      </form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>