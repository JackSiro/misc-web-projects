<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	?>
  <h4><strong>Username</strong> <em>Recovery Center</em></h4>
				
				<hr>
				<p>Username recovery was successful as:</p><br>
				<h2><?php echo $_SESSION['recover_username'] ?></h2><hr>
			<a href="index.php"><h2>>> Now Login In >></h2></a>
      
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>