<?php include AS_THEME."as_header.php"; ?>
	<h2>Register your account now!!!</h2> 
          <br><hr><br>
			<div id="contact_form">
				<form role="form" method="post" name="PostUser" action="index.php?page=register" enctype="multipart/form-data" >
                
				
				<label>First  Name:</label>
				<input class="input_field" type="text" autocomplete="off" name="fname">

				<label>Second Name:</label>
				<input class="input_field" type="text" autocomplete="off" name="surname">

				<label>Upload User Avatar:</label>
				<input class="input_field" name="avatar" autocomplete="off" type="file" accept="image/*">

                
				<label>Email Address:</label>
				<input class="input_field" type="text" autocomplete="off" name="email">

				
				<label>Mobile (Optional):</label>
				<input class="input_field" type="text" autocomplete="off" name="mobile">

				
				<label>Preferred Username:</label>
				<input class="input_field" type="text" autocomplete="off" name="username">

				
				<label>Preferred Password:</label>
				<input class="input_field" type="password" autocomplete="off" name="password">

				
				<label>Confirm Password:</label>
				<input class="input_field" type="password" autocomplete="off" name="passwordcon">
				
				<div class="cleaner"></div>
				<input type="submit" name="Register" value="Register" class="submit_btn" />
			  </form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>