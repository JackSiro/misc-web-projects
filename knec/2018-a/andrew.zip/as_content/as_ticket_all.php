<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	$database = new As_Dbconn();			
	
		$as_db_query = "SELECT * FROM as_ticket ORDER BY ticketid DESC";
		$results = $database->get_results( $as_db_query );
	?>

        <div class="cleaner h20"></div>

   	  	<div>
            <h4><strong><?php echo $database->as_num_rows( $as_db_query ) ?> Tickets</strong>
		  <em><a style="float:right;width:300px;text-align:center;" href="index.php?page=booking">New Ticket</a></em></h4><hr>
				<table class="tt_tb">
				<thead><tr class="tt_tr">
				  <th>customer</th>
				  <th>mobile</th>
				  <th>date</th>
				  <th>type</th>
				  <th>stand</th>
				  <th>booking</th>
				  <th>amount</th>
				  <th>payment</th>
				</tr></thead>
				<tbody>
                <?php foreach( $results as $row ) { ?>
		        <tr onclick="location='index.php?page=ticket_view&amp;as_ticketid=<?php echo $row['ticketid'] ?>'">
					<td><?php echo $row['ticket_customer'] ?></td>
				<td><?php echo $row['ticket_mobile'] ?></td>
				<td><?php echo $row['ticket_date'] ?></td>
				<td><?php echo $row['ticket_type'] ?></td>
				<td><?php echo $row['ticket_stand'] ?></td>
				<td><?php echo $row['ticket_booking'] ?></td>
				<td><?php echo $row['ticket_amount'] ?></td>
				<td><?php echo $row['ticket_payment'] ?></td>
		        </tr>
			
			<?php } ?>
			
                      </tbody>
                    </table>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>