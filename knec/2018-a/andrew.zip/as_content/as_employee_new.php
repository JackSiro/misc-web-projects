<?php include AS_THEME."as_header.php"; ?>
		  <h2>Add an Company User</h2> 
          <br><hr><br>
			<div id="contact_form">
				<form method="post" action="index.php?page=employee_new" enctype="multipart/form-data" >
                
				<label>Choose a Category:</label>
				<select name="group" class="input_field">
						<option value="" > - Choose a Category - </option>
						<option value="super-admin" > Super Admin </option>
						<option value="admin" > Admin </option>
						<option value="manager" > Manager </option>
						<option value="editor" > Editor </option>
						<option value="xplorer" > Explorer </option>		
				</select>
				
				<label>First  Name:</label>
				<input class="input_field" type="text" autocomplete="off" name="fname">

				<label>Second Name:</label>
				<input class="input_field" type="text" autocomplete="off" name="surname">

				<label>Upload User Avatar:</label>
				<input class="input_field" name="avatar" autocomplete="off" type="file" accept="image/*">

                
				<label>Email Address:</label>
				<input class="input_field" type="text" autocomplete="off" name="email">

				
				<label>Mobile (Optional):</label>
				<input class="input_field" type="text" autocomplete="off" name="mobile">

				
				<label>Preferred Username:</label>
				<input class="input_field" type="text" autocomplete="off" name="username">

				
				<label>Preferred Password:</label>
				<input class="input_field" type="password" autocomplete="off" name="password">

				
				<label>Confirm Password:</label>
				<input class="input_field" type="password" autocomplete="off" name="passwordcon">
				
				<div class="cleaner"></div>
                <input type="submit" name="AddEmployee" value="Save & Add" class="submit_btn" />
                <input type="submit" name="AddClose" value="Save & Close" class="submit_btn" />
				</form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>