<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
?>
			<h2><strong>Book</strong> <em>A Ticket Now!!!</em></h2><hr>
			<form method="post" action="index.php?action=ticket_new" enctype="multipart/form-data" >
				<label>Customer Name:</label>
				<input type="text" class="input_field" autocomplete="off" name="customer" required >
				
				<label>Mobile Number:</label>
				<input type="text" class="input_field" autocomplete="off" name="mobile" required />
							
				<label>Ticket Date:</label>
				<input type="text" class="input_field" autocomplete="off" name="date" placeholder="DD-MM-YYYY" required >
				
				<label>Ticket Type:</label>
				<select name="type" class="input_field" required >
					<option value="" > - Ticket Type - </option>
					<option value="VIP" > VIP Class </option>
					<option value="Normal" > Normal </option>
				</select>
							
				<label>Stand Type:</label>
				<select name="stand" class="input_field" required >
					<option value="" > - Stand Type - </option>
					<option value="VIP" > VIP Class </option>
					<option value="Normal" > Normal </option>
				</select>
				
				<label>Booking Type:</label>
				<select name="booking" class="input_field" required >
					<option value="" > - Booking Type - </option>
					<option value="Advance" > Advance Booking </option>
					<option value="Normal" > Normal Booking </option>
				</select>
							
				<label>Amount Paid:</label>
				<input type="text" class="input_field" autocomplete="off" name="amount" required >
				
				<label>Mode of Payment:</label>
				<select name="payment" class="input_field" required >
					<option value="" > - Mode of payment - </option>
					<option value="Cash payment"> Cash payment </option>
					<option value="Mpesa/AirtelMoney"> Mpesa/AirtelMoney </option>
					<option value="Cheque"> Cheque </option>
					<option value="Visa Card"> Visa Card </option>
				</select>
				
				<div class="cleaner"></div>
                    <input type="submit" name="BookNow" value="Finish" class="submit_btn" />
                </form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>