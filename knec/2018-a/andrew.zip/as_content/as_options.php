<?php include AS_THEME."as_header.php"; ?>
	<div id="site_content">	

	  <div id="content"> 
        
	  
        <div class="content_item">
		<br>
		  <h2>Site Options</h2> 
          <br><hr><br>
			<div id="contact_form">
				<form action="index.php?page=options" method="post">
				<center><h2><b><u>Site Options</u></b></h2></center><br>
                
				<label>Site Name:</label>
				<input type="text" name="sitename" value="<?php echo as_get_option('sitename') ?>">

                <label>Site Url:</label>
				<input type="text" name="siteurl" autocomplete="off" value="<?php echo as_get_option('siteurl') ?>">

                <label>Keywords:</label>
				<input type="text" name="keywords" autocomplete="off" value="<?php echo as_get_option('keywords') ?>">

                <label>Descriptions:</label>
				<textarea name="description"><?php echo as_get_option('description') ?></textarea>

				</table><br>
                        <center><input type="submit" class="submit_this" name="SaveSite" value="Save Options">
			  </center><br></form>
				
			</div>
		<br>
      <h2><center></center></h2>
		<br>  
		</div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
  </div><!--close main-->
<?php include AS_THEME."as_footer.php" ?>
    
