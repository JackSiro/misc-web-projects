<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	?>
	<h4><strong>Password</strong> <em>Recovery Center</em></h4>
				
				<hr>
				<p>Sorry for Loosing your password. Fill in the form below to get assistance on recovering your password.</p><br>
				<form action="index.php?page=forgot_password" method="post" >
				
				<tr>
					<td>Enter your username (*)</td>
					<td><input type="text" name="username" id="username" autocomplete="off" required autofocus  /></td>
				</tr>
				<tr><td>Enter your email (*)</td>
				</td><td>
				<input type="email" name="email" id="email" autocomplete="off" required autofocus />
				</td></tr>
				</table>
				<input type="submit" id="aalogin-button" name="ForgotPassword" value="Forgot Password" />
			
				</form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>