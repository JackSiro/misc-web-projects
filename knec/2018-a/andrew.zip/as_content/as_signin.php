<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
?>
            <h2>Sign in to Your Account to Continue</h2>
			<div id="contact_form">
                <form method="post" action="index.php?page=login">
                    <label>Username:</label>
				    <input type="text" id="username" name="username" class="input_field" />

                    <label>Password:</label>
				    <input type="password" id="password" name="password" class="input_field" />

                    <div class="cleaner"></div>
                    <input type="submit" name="SignMeIn" value="Sign In" class="submit_btn" />
                </form>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>