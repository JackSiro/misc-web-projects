<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
	$database = new As_Dbconn();			

	$ticketid = $results['item'];
	$as_db_query = "SELECT * FROM as_ticket WHERE ticketid = '$ticketid'";
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
		list( $ticketid, $ticket_customer,$ticket_mobile, $ticket_date, $ticket_type, $ticket_stand, $ticket_booking, $ticket_amount, $ticket_payment) = $database->get_row( $as_db_query );
	}
		
?>
	<h2><strong>Ticket</strong> <em>View</em></h2>
		<div id="contact_form">
				<table class="view_tb" border="2" style="text-transform:uppercase; line-height:25px;">
				  <tr>
				    <td>Customer:<br><?php echo $ticket_customer ?></td>
				    <td>Mobile:<br><?php echo $ticket_mobile ?></td>
				  </tr>
				  <tr>
				    <td>Event Date:<br><?php echo $ticket_date ?></td>
				    <td>Ticket Type:<br><?php echo $ticket_type ?></td>
				  </tr>
				  <tr>
				    <td>Stand Type:<br><?php echo $ticket_stand ?></td>
				    <td>Type of Booking:<br><?php echo $ticket_booking ?></td>
				  </tr>
				  <tr>
				    <td>Amount:<br>KES. <?php echo $ticket_amount ?>.00</td>
				    <td>Payment Mode:<br><?php echo $ticket_payment ?></td>
				  </tr>
				</table>
				<br><br>
				<center><h2><a href="index.php?page=ticket_delete&&as_ticketid=<?php echo $ticketid ?>" onclick="return confirm('Are you sure you want to delete this item from the system? \nBe careful, this page can not be reversed.')">Delete this Ticket</a></h2></center>
              
		<div class="cleaner h40"></div>
	</div>
<?php include AS_THEME."as_footer.php" ?>