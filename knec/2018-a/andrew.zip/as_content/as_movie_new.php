<?php include AS_THEME."as_header.php";
	$myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : "";
?>
	<h2>Add a Movie</h2>
	<div id="contact_form">
		<form method="post" action="index.php?page=movie_new" >
		<label>Movie Type:</label>
		<select name="movie_type" class="input_field" required>
			<option></option>
			<option value="Horror">Horror</option>
			<option value="Fiction">Fiction</option>
			<option value="Action">Action</option>
			<option value="Romance">Romance</option>
		</select>
		
		<label>Movie Title:</label>
		<input type="text" class="input_field" autocomplete="off" name="movie_title" required />
		
		<label>Language:</label>
		<select name="movie_language" class="input_field" required>
			<option></option>
			<option value="English">English</option>
			<option value="Kiswahili">Kiswahili</option>
			<option value="French">French</option>
			<option value="Spanish">Spanish</option>
		</select>
	
		<label>Movie Price:</label>
		<input type="number" class="input_field" autocomplete="off" name="movie_price" required />
		
		<label>Movie Year:</label>
		<input type="number" class="input_field" autocomplete="off" name="movie_year" required />
		
		<label>Description:</label>
		<textarea class="input_field" name="movie_description" required></textarea>
							
		<div class="cleaner"></div>
			<input type="submit" name="SaveMovie" value="Save Movie" class="submit_btn" />
		</form>
		<div class="cleaner h40"></div>
	</div>
<?php include AS_THEME."as_footer.php" ?>