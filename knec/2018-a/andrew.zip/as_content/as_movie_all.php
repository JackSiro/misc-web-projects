<?php include AS_THEME."as_header.php";
	$database = new As_Dbconn();			
	
	$as_db_query = "SELECT * FROM as_movie ORDER BY movieid DESC";
	$results = $database->get_results( $as_db_query );
?>

        <div class="cleaner h20"></div>

   	  	<div>
            <h4><strong><?php echo $database->as_num_rows( $as_db_query ) ?> Movies</strong>
		  <em><a style="float:right;width:300px;text-align:center;" href="index.php?page=movie_new">New Movie</a></em></h4><hr>
				<table class="tt_tb">
				<thead><tr class="tt_tr">
				  <th>Type</th>
				  <th>title</th>
				  <th>language</th>
				  <th>price</th>
				  <th>year</th>
				</tr></thead>
				<tbody>
                <?php foreach( $results as $row ) { ?>
		        <tr onclick="location='index.php?page=movie_view&amp;as_movieid=<?php echo $row['movieid'] ?>'">
					<td><?php echo $row['movie_title'] ?></td>
				<td><?php echo $row['movie_type'] ?></td>
				<td><?php echo $row['movie_language'] ?></td>
				<td><?php echo $row['movie_price'] ?></td>
				<td><?php echo $row['movie_year'] ?></td>
		        </tr>
			<?php } ?>
			
                      </tbody>
                    </table>
				<div class="cleaner h40"></div>
            </div>
			<div class="cleaner"></div>
<?php include AS_THEME."as_footer.php" ?>