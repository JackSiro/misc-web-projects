<div class="cleaner"></div>
        
    </div>
    <div id="tooplate_main_bottom"></div>
    
    <div id="tooplate_footer">
        
        Copyright © <?php echo date('Y') ?> <a href="."><?php echo as_get_option('sitename') ?></a> 
        - Design: <a href="#" target="_parent">Andrew Kimani</a>
    
    </div>
</div>
</body>
</html>