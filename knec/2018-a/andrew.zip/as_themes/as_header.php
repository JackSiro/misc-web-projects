<?php $myaccount = isset( $_SESSION['tickets_account'] ) ? $_SESSION['tickets_account'] : ""; ?> 
<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo as_get_option('sitename') ?></title>
<meta charset="utf-8">
<link href="as_themes/tooplate_style.css" rel="stylesheet" type="text/css" />

<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>
</head>
<body>

<div id="tooplate_wrapper">
	<div id="tooplate_top">
        <div id="tooplate_menu">
            <ul>
              <li><a href=".">Home</a></li>
		<?php if (!$myaccount){	?>
			<li><a href="index.php?page=register">Register</a></li>		
			<li><a href="index.php?page=forgot_password">Forgot Password</a></li>		
			<li><a href="index.php?page=forgot_username ">Forgot Username</a></li>		
		<?php } else if ($myaccount){ ?>
			<li><a href="index.php?page=ticket_all">Tickets</a></li>
			<li><a href="index.php?page=movie_all">Movies</a></li>
			<li><a href="index.php?page=employee_all">Employees</a></li>
			<li><a href="index.php?page=logout">Logout?</a></li>
		<?php } ?>
            </ul>    	
        </div>
		<?php if (!$myaccount){	?>
        <div id="login_box">
            <form action="index.php?page=login" method="get">
                <input type="text" name="username" value="Username" class="login_field" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="password" name="password" value="Password" class="login_field" onfocus="clearText(this)" onblur="clearText(this)" />
                <input type="submit" name="SignMeIn" id="login_btn" title="Login" />
            </form>
        </div>
		<?php } ?>
	</div>
    <div id="tooplate_main_top"></div>
    <div id="tooplate_main">
    	
        <div class="cleaner h20"></div>