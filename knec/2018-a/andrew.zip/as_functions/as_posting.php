<?php
	// POSTING FUNCTIONS
	// Begin Posting Functions 
	
	function as_slug_this($content) {
		return preg_replace("/-$/","",preg_replace('/[^a-z0-9]+/i', "-", strtolower($content)));
	}
	
	function as_slug_is(){
		if(empty($_POST['slug'])) {
		    $as_slug = trim($_POST['slug']);
		} else $as_slug = as_slug_this($_POST['title']);
		
	}
					
	function as_add_new_movie(){		
		$database = new As_Dbconn();			
		$New_Bus_Details = array(	
			'movie_type' => trim($_POST['movie_type']),
			'movie_title' => trim($_POST['movie_title']),
			'movie_language' => trim($_POST['movie_language']),
			'movie_price' => trim($_POST['movie_price']),
			'movie_description' => trim($_POST['movie_description']),
			'movie_year' => trim($_POST['movie_year']),
			'movie_posted' => date('Y-m-d H:i:s'),
			'movie_postedby' => "1",
		);
		$add_query = $database->as_insert( 'as_movie', $New_Bus_Details ); 
	}
	
	function as_edit_movie($movieid) {
		$database = new As_Dbconn();	
		$Update_Item_Details = array(
			'movie_type' => trim($_POST['movie_type']),
			'movie_title' => trim($_POST['movie_title']),
			'movie_language' => trim($_POST['movie_language']),
			'movie_price' => trim($_POST['movie_price']),
			'movie_description' => trim($_POST['movie_description']),
			'movie_year' => trim($_POST['movie_year']),
			'movie_updated' => date('Y-m-d H:i:s'),
			'movie_updatedby' => "1",
		);
		$where_clause = array('movieid' => $movieid);
		$updated = $database->as_update( 'as_movie', $Update_Item_Details, $where_clause, 1 );
	}
	
	function as_add_new_ticket(){
		$database = new As_Dbconn();			
		$New_Item_Details = array(
			'ticket_customer' => trim($_POST['customer']),
			'ticket_mobile' => trim($_POST['mobile']),
			'ticket_date' => trim($_POST['date']),
			'ticket_type' => trim($_POST['type']),
			'ticket_stand' => trim($_POST['stand']),
			'ticket_booking' => trim($_POST['booking']),
			'ticket_amount' => trim($_POST['amount']),
			'ticket_payment' => trim($_POST['payment']),
		    'ticket_posted' => date('Y-m-d H:i:s'),
		    'ticket_postedby' => "1",
		);
			
		$add_query = $database->as_insert( 'as_ticket', $New_Item_Details ); 
	}
	
	function as_edit_ticket($ticketid) {
		$database = new As_Dbconn();	
		$Update_Item_Details = array(
			'ticket_customer' => trim($_POST['customer']),
			'ticket_mobile' => trim($_POST['mobile']),
			'ticket_date' => trim($_POST['date']),
			'ticket_type' => trim($_POST['type']),
			'ticket_stand' => trim($_POST['stand']),
			'ticket_booking' => trim($_POST['booking']),
			'ticket_amount' => trim($_POST['amount']),
			'ticket_payment' => trim($_POST['payment']),
		);
		$where_clause = array('ticketid' => $ticketid);
		$updated = $database->as_update( 'as_ticket', $Update_Item_Details, $where_clause, 1 );
		if( $updated )	{	}
	}
	
?>