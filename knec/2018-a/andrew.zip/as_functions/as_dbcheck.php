 <?php
	
	$database = new As_Dbconn();
	
	$As_Table_Details = array(	
		'optid int(11) NOT NULL AUTO_INCREMENT',
		'title varchar(100) NOT NULL',
		'content varchar(2000) NOT NULL',
		'createdby int(10) unsigned DEFAULT NULL',
		'created datetime DEFAULT NULL',
		'updatedby int(10) unsigned DEFAULT NULL',
		'updated datetime DEFAULT NULL',
		'PRIMARY KEY (optid)',
		);
	$add_query = $database->as_table_exists_create( 'as_options', $As_Table_Details ); 
	
	//ticketid, ticket_customer, ticket_mobile, ticket_date, ticket_type, ticket_stand, ticket_booking, ticket_amount, ticket_payment, 
	$As_Table_Details = array(
		'ticketid int(10) unsigned NOT NULL AUTO_INCREMENT',
		'ticket_customer varchar(100) DEFAULT NULL',
		'ticket_mobile varchar(100) DEFAULT NULL',
		'ticket_date varchar(100) DEFAULT NULL',
		'ticket_type varchar(100) DEFAULT NULL',
		'ticket_stand varchar(100) DEFAULT NULL',
		'ticket_booking varchar(100) DEFAULT NULL',
		'ticket_amount varchar(100) DEFAULT NULL',
		'ticket_payment varchar(100) DEFAULT NULL',
		'ticket_postedby int(10) unsigned DEFAULT 0',
		'ticket_posted datetime DEFAULT NULL',
		'ticket_updated datetime DEFAULT NULL',
		'ticket_updatedby int(10) DEFAULT NULL',
		'PRIMARY KEY (ticketid)',
		);
	$add_query = $database->as_table_exists_create( 'as_ticket', $As_Table_Details ); 
	
	//movieid, movie_type, movie_title, movie_language, movie_price, movie_description, movie_year,
	$As_Table_Details = array(
		'movieid int(10) unsigned NOT NULL AUTO_INCREMENT',
		'movie_type varchar(100) DEFAULT NULL',
		'movie_title varchar(100) DEFAULT NULL',
		'movie_language varchar(100) DEFAULT NULL',
		'movie_price varchar(100) DEFAULT NULL',
		'movie_description varchar(1000) DEFAULT NULL',
		'movie_year varchar(50) DEFAULT NULL',
		'movie_postedby int(10) unsigned DEFAULT 0',
		'movie_posted datetime DEFAULT NULL',
		'movie_updated datetime DEFAULT NULL',
		'movie_updatedby int(10) DEFAULT NULL',
		'PRIMARY KEY (movieid)',
		);
	$add_query = $database->as_table_exists_create( 'as_movie', $As_Table_Details ); 
	
	$As_Table_Details = array(	
		'employeeid int(11) NOT NULL AUTO_INCREMENT',
		'employee_name varchar(50) NOT NULL',
		'employee_fname varchar(50) NOT NULL',
		'employee_surname varchar(50) NOT NULL',
		'employee_sex varchar(10) NOT NULL',
		'employee_password text NOT NULL',
		'employee_email varchar(200) NOT NULL',
		'employee_group varchar(50) NOT NULL DEFAULT "buyer"',
		'employee_joined datetime DEFAULT NULL',
		'employee_mobile varchar(50) NOT NULL',
		'employee_web varchar(100) NOT NULL',
		'employee_avatar varchar(50) NOT NULL DEFAULT "employee_default.jpg"',
		'PRIMARY KEY (employeeid)',
		);
	$add_query = $database->as_table_exists_create( 'as_employee', $As_Table_Details ); 
	
?>