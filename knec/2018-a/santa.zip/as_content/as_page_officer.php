<?php
	$database = new As_Dbconn();
	$as_pageinfo = array();
	$html = '';
	$as_officerid = isset( $_GET['as_officerid'] ) ? $_GET['as_officerid'] : "";
	$officer_sexs = array(
		array('value' => 'M', 'option' => 'Male'), 
		array('value' => 'F', 'option' => 'Female'),
	);
				
	switch ( $request_two ) {
		case 'new'.as_urlExt: {
				$as_pageinfo['pageTitle'] = 'New Officer';
				
				$fields = array(
					'officer_name' => array(
						'label' => 'Full Name:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'officer_sex' => array(
						'label' => 'Officer Sex:', 
						'type' => 'radio',
						'value' => 'M',
						'options' => $officer_sexs,
					),
					
					'officer_mobile' => array(
						'label' => 'Mobile Phone:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'officer_email' => array(
						'label' => 'Email Address:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'officer_location' => array(
						'label' => 'Location:', 
						'type' => 'textarea', 
						'tags' => 'autocomplete="off"',
					),
					
				);
				
				$buttons = array(
					'SaveItem' => 'Save and Add',
					'SaveClose' => 'Save and Close',
				);
				
				$html .= as_form_format( $fields, $buttons, as_menu_handler('officers/new'));
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'view'.as_urlExt: {
				$as_db_query = "SELECT * FROM as_officers WHERE officerid=$as_officerid";
				list( $officerid, $officer_name, $officer_sex, $officer_mobile, $officer_email, $officer_location) = $database->get_row( $as_db_query );

				$as_pageinfo['pageTitle'] = 'View Officer :: '.$officer_name.' ('.$officer_sex.')';
				$as_pageinfo['pageLink'] = '<a style="float:right;" href="'.as_menu_handler('officers/edit').'?as_officerid='.$as_officerid.'">EDIT THIS OFFICER</a>';
				
				$html .= '<table style="width:90%;font-size:20px;">';
				$html .= '<tr><td><b>Email Address: </b></td><td style="width:30px;"><b> : </b></td><td> '.$officer_email.'</tr>';
				$html .= '<tr><td><b>Mobile Phone</b></td><td><b> : </b></td><td> '.$officer_mobile.'</tr>';
				$html .= '<tr><td><b>Location</b></td><td><b> : </b></td><td> '.$officer_location.'</tr>';
				$html .= '</table>';
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'edit'.as_urlExt: {
				$as_db_query = "SELECT * FROM as_officers WHERE officerid=$as_officerid";
				list( $officerid, $officer_name, $officer_sex, $officer_mobile, $officer_email, $officer_location) = $database->get_row( $as_db_query );

				$as_pageinfo['pageTitle'] = 'Edit Officer :: '.$officer_name.' ('.$officer_sex.')';
				$as_pageinfo['pageLink'] = '<a style="float:right;" onclick="return confirm(\'Are you sure you want to delete this officer from the system? \nBe careful, this action can not be reversed.\')" href="'.as_menu_handler('officers/delete').'?as_officerid='.$as_officerid.'">DELETE THIS OFFICER?</a>';
				
				$fields = array(
					'officer_name' => array(
						'label' => 'Full Name:', 
						'type' => 'text', 
						'value' => $officer_name,
						'tags' => 'autocomplete="off"',
					),
					
					'officer_sex' => array(
						'label' => 'Officer Sex:', 
						'type' => 'radio',
						'value' => $officer_sex,
						'options' => $officer_sexs,
					),
					
					'officer_mobile' => array(
						'label' => 'Mobile Phone:', 
						'type' => 'text',
						'value' => $officer_mobile, 
						'tags' => 'autocomplete="off"',
					),
					
					'officer_email' => array(
						'label' => 'Email Address:', 
						'type' => 'text', 
						'value' => $officer_email,
						'tags' => 'autocomplete="off"',
					),
					
					'officer_location' => array(
						'label' => 'Location:', 
						'type' => 'text', 
						'value' => $officer_location,
						'tags' => 'autocomplete="off"',
					),
					
				);
				
				$buttons = array(
					'UpdateItem' => 'Update Only',
					'UpdateClose' => 'Update and Close',
				);
				
				$html .= as_form_format( $fields, $buttons, as_menu_handler('officers/view').'?as_officerid='.$as_officerid);
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'delete'.as_urlExt: {
				$as_pageinfo['pageContent'] = $as_pageinfo['pageTitle'] = '';
				$delete = array( 'officerid' => $as_officerid );
				$deleted = $database->delete( 'as_officer', $delete, 1 );
				header("location: ".as_menu_handler('officers/all') );
			}
			break;			
		default:{
			$as_pageinfo['pageLink'] = '<a style="float:right;font-size: 25px;" href="'.as_menu_handler('officers/new').'">+ NEW OFFICER</a>';
			
			$rows = array('officer_name', 'officer_mobile', 'officer_email', 'officer_location' );
			$as_db_query = "SELECT * FROM as_officers ORDER BY officerid DESC";	
			$results = $database->get_results( $as_db_query );
			$as_pageinfo['pageTitle'] = 'List of Officers ('.$database->as_num_rows( $as_db_query ).')';
			$theader_arr = array('Name', 'Mobile', 'Email', 'Location');
			$html .= as_table_format($theader_arr, $rows, $results, 
				as_menu_handler('officers/view').'?as_officerid=', 'officerid' );
			$as_pageinfo['pageContent'] = $html;
		}
	}
	
	if (as_clicked('SaveItem')) {
		as_new_officer();
		header("location: ".as_menu_handler('officers/new'));
	} else if (as_clicked('SaveClose')) {
		as_new_officer();
		header("location: ".as_menu_handler('officers/all'));
	} else if (as_clicked('UpdateItem')) {
		as_edit_officer($as_officerid);
		as_menu_handler('officers/view').'?as_officerid='.$as_officerid;
	} else if (as_clicked('UpdateClose')) {
		as_edit_officer($as_officerid);
		header("location: ".as_menu_handler('officers/all'));
	} else {
		require_once AS_FUNC."as_paging.php";	
		include AS_THEME."as_header.php";
		echo  $as_pageinfo['pageContent'];
		include AS_THEME."as_footer.php";
	}