<?php
	$database = new As_Dbconn();
	$as_pageinfo = array();
	$html = '';
	$as_officerid = isset( $_GET['as_officerid'] ) ? $_GET['as_officerid'] : "";
	
	switch ( $request_two ) {
		case 'new'.as_urlExt: {
				$as_pageinfo['pageTitle'] = 'New User';
				$fields = array(
					'officer_type' => array(
						'label' => 'User Type:', 
						'type' => 'select',
						'value' => 'In-User',
						'options' => $officer_types,
					),
					
					'officer_name' => array(
						'label' => 'Full Name:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'officer_sex' => array(
						'label' => 'User Sex:', 
						'type' => 'radio',
						'value' => 'M',
						'options' => $officer_sexs,
					),
					
					'officer_client' => array(
						'label' => 'User Delivery:',
						'type' => 'select',
						'options' => $officer_client,
					),
					
					'officer_age' => array(
						'label' => 'User Age:',
						'type' => 'number',
						'tags' => ' min="2"',
					),
					
					'officer_location' => array(
						'label' => 'Physical Address:',
						'type' => 'textarea',
					),
					
					'officer_idno' => array(
						'label' => 'Sickness:',
						'type' => 'textarea',
					),
					
					'officer_admitted' => array(
						'label' => 'Date of Admission:',
						'type' => 'text',
						'value' => date('d/m/Y'),
					),
					
					'officer_fees' => array(
						'label' => 'Session (Kshs):',
						'type' => 'number',
						'tags' => ' min="2000"',
					),
					
				);
				
				$buttons = array(
					'SaveItem' => 'Save and Add',
					'SaveClose' => 'Save and Close',
				);
				
				$html .= as_form_format( $fields, $buttons, as_menu_handler('officers/new'));
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'view'.as_urlExt: {
				$as_db_query = "SELECT officerid, officer_type, officer_client, officer_name, officer_sex, officer_age, officer_picture, officer_location, officer_idno, officer_admitted, officer_fees, client_ward, client_number FROM as_officers 
					LEFT JOIN as_clients ON as_officers.officer_client = as_clients.clientid 
					WHERE officerid = $as_officerid";
				list( $officerid, $officer_type, $officer_client, $officer_name, $officer_sex, $officer_age, $officer_picture, $officer_location, $officer_idno, $officer_admitted, $officer_fees, $officer_posted) = $database->get_row( $as_db_query );

				$as_pageinfo['pageTitle'] = 'User '.$officer_name.' ('.$officer_sex.')';
				$as_pageinfo['pageLink'] = '<a style="float:right;" href="'.as_menu_handler('officers/edit').'?as_officerid='.$as_officerid.'">EDIT THIS PATIENT</a>';
				
				$html .= '<hr><table style="width:90%;font-size:20px;">';
				$html .= '<tr><td><b>Age:</b></td><td>'.$officer_age.' yrs.</tr>';
				$html .= '<tr><td valign="top"><b>Location:</b></td><td><p>'.$officer_location.'</p></tr>';
				$html .= '<tr><td valign="top"><b>Sickness:</b></td><td><p>'.$officer_idno.'</p></tr>';
				$html .= '<tr><td><b>Age:</b></td><td>Ward '.$officer_age.' yrs.</tr>';
				$html .= '<tr><td><b>Delivery No:</b></td><td>';
				if ($officer_client == 0) $html .= ' - ';
				else $html .= 'Ward '.$client_ward.' Delivery '.$client_number;
				$html .= '</tr>';
				$html .= '<tr><td><b>Date Admitted:</b></td><td>'.$officer_admitted.'</tr>';
				$html .= '<tr><td><b>Amount Paid (Kshs):</b></td><td>'.$officer_fees.'/=</tr>';
				$html .= '</table>';
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'edit'.as_urlExt: {
				$as_db_query = "SELECT * FROM as_officers 
					LEFT JOIN as_clients ON as_officers.officer_client = as_clients.clientid 
					WHERE officerid = $as_officerid";
				list( $officerid, $officer_ward, $officer_number, $officer_type, $officer_officer) = $database->get_row( $as_db_query );

				$as_pageinfo['pageTitle'] = 'View User #'.$as_officerid;
				$as_pageinfo['pageLink'] = '<a style="float:right;" onclick="return confirm(\'Are you sure you want to delete this officer from the system? \nBe careful, this action can not be reversed.\')" href="'.as_menu_handler('officers/delete').'?as_officerid='.$as_officerid.'">DELETE THIS PATIENT?</a>';
				
				$fields = array(
					'officer_ward' => array(
						'label' => 'User Ward:',
						'type' => 'text',
						'value' => $officer_ward,
					),
					
					'officer_number' => array(
						'label' => 'User Number:',
						'type' => 'text',
						'tags' => 'autocomplete="off"',
						'value' => $officer_number,
					),
					
					'officer_type' => array(
						'label' => 'User Type:',
						'type' => 'text',
						'value' => $officer_type
					),
				);
				
				$buttons = array(
					'UpdateItem' => 'Update and Add',
					'UpdateClose' => 'Update and Close',
				);
				
				$html .= as_form_format( $fields, $buttons, as_menu_handler('officers/view').'?as_officerid='.$as_officerid);
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'delete'.as_urlExt: {
				$as_officerid = isset( $_GET['as_officerid'] ) ? $_GET['as_officerid'] : "";
				$delete = array( 'officerid' => $as_officerid );
				$deleted = $database->delete( 'as_officer', $delete, 1 );
				if ( $deleted )	header( as_menu_handler('officers/all') );
				else header( as_menu_handler('officers/view').'?as_officerid='.$as_officerid );
			}
			break;			
		default:{
			$as_pageinfo['pageTitle'] = 'List of Users';
			$as_pageinfo['pageLink'] = '<a style="float:right;" href="'.as_menu_handler('officers/new').'">ADD A NEW PATIENT</a>';
			
			$rows = array('officer_name', 'officer_type', 'officer_age', 'officer_location', 'officer_idno', 'officer_admitted', 'officer_fees');
			$rw_check = array(' - ', 'officer_client', 'client_ward', 'client_number', 'Ward', 'Delivery' );
			$as_db_query = "SELECT officerid, officer_type, officer_client, officer_name, officer_sex, officer_age, officer_picture, officer_location, officer_idno, officer_admitted, officer_fees, client_ward, client_number FROM as_officers 
					LEFT JOIN as_clients ON as_officers.officer_client = as_clients.clientid
					ORDER BY officerid DESC";	
			$results = $database->get_results( $as_db_query );
			$theader_arr = array('Name', 'Type', 'Age', 'Location', 'Sickness', 'Admitted', 'Amount', 'Delivery_No.');
			$html .= as_table_format($theader_arr, $rows, $results, 
				as_menu_handler('officers/view').'?as_officerid=', 'officerid', $rw_check );
			$as_pageinfo['pageContent'] = $html;
		}
	}
	
	if (as_clicked('SaveItem')) {
		as_new_officer();
		header("location: ".as_menu_handler('officers/new'));
	} else if (as_clicked('SaveClose')) {
		as_new_officer();
		header("location: ".as_menu_handler('officers/all'));
	} else {
		require_once AS_FUNC."as_paging.php";	
		include AS_THEME."as_header.php";
		echo  $as_pageinfo['pageContent'];
		include AS_THEME."as_footer.php";
	}