<?php
	$as_pageinfo = array();	 
	$as_pageinfo['pageTitle'] = 'Welcome Home';
	
	$style = isset( $_GET['as_style'] ) ? $_GET['as_style'] : "grid";
	$max = isset( $_GET['as_max'] ) ? $_GET['as_max'] : 20;
	
	$database = new As_Dbconn();
	$as_db_query = "SELECT * FROM as_officers ORDER BY officerid DESC LIMIT $max";	
	$results = $database->get_results( $as_db_query );
	
	require_once AS_FUNC."as_paging.php";	
	include AS_THEME."as_header.php";
?>
<div id="main_content">
    <div class="column1">
      <div class="left_box">
        <div class="top_left_box"> </div>
        <div class="center_left_box">
          <div class="box_title"><span>Join</span> our newsletter:</div>
          <div class="form">
            <div class="form_row">
              <label class="left">Email: </label>
              <input type="text" class="form_input"/>
            </div>
            <div style="float:right; padding:10px 25px 0 0;">
              <input type="image" src="<?php echo as_siteUrl ?>as_themes/images/join.gif"/>
            </div>
          </div>
        </div>
        <div class="bottom_left_box"> </div>
      </div>
      <div class="left_box">
        <div class="top_left_box"> </div>
        <div class="center_left_box">
          <div class="box_title"><span>Contact</span> information:</div>
          <div class="form">
            <div class="form_row"> <img src="<?php echo as_siteUrl ?>as_themes/images/general_envelope.gif" width="50" height="47" border="0" class="img_right" alt="" />
              <div class="general_information"> Email: viatu.com<br />
                Telephone: 0719751319<br />
                Mobile: 0719751319<br />
                facebook: Viatu Sale<br />
                twitter:@viatu_ke<br/>
                <br />
                <span>www.viatu.com</span> </div>
            </div>
          </div>
        </div>
        <div class="bottom_left_box"> </div>
      </div>
    </div>
    <!-- end of column one -->
    <div class="column4">
      <div class="title" style="float:left;">
        <div style="float:left;">Latest Officers</div>
        <div style="float:right; font-size:10px;color:#d8325d;padding-top:2px;">Display: 
			<a href="<?php echo as_menu_handler("index").'?as_style=list' ?>">
				<img src="<?php echo as_siteUrl ?>as_themes/images/list_style3.gif" border="0" />
			</a> 
			<a href="<?php echo as_menu_handler("index").'?as_style=grid' ?>">
				<img src="<?php echo as_siteUrl ?>as_themes/images/list_style1.gif" border="0" />
			</a>
		</div>
      </div>
	  <?php if ($style == 'grid') { 
		foreach ($results as $row) { 
		$link = as_menu_handler("officer/view").'?as_officerid='.$row['officerid'];
		?>
      <div class="officer_box_wide"> <a href="<?php echo $link ?>"><img src="<?php echo as_siteUrl ?>as_media/posts/<?php echo $row['officer_picture'] ?>" width="130" height="98" class="img_left" alt="" border="0"/>
        <div class="officer_info"> <span><?php echo $row['officer_name'] ?></span>
			<p>Price: <?php echo $row['officer_age'] ?></p>
          <p class="offer"> <?php echo $row['officer_sex'] ?></p>
          <div class="more">Buy this item</div>
        </div></a>
      </div>
	  <?php }
	  } else if ($style == 'list'){ ?>
	  <table style="clear:both; width:695px; margin-top:10px;" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <th>Title</th>
          <th>Description</th>
          <th>Price</th>
        </tr>
		<?php foreach ($results as $row) { ?>
        <tr class="color1" onmouseout="style.backgroundColor='#F3F5F6'" onclick="document.location.href='#'" onmouseover="this.style.cursor='pointer'; style.backgroundColor='#ffffff'" title="Vezi detaliile anuntului" >
          <td><a href="#"><img src="as_media/posts/<?php echo $row['officer_picture'] ?>" width="130" height="98" class="img_left" alt="" border="0"/></a></td>
          <td><?php echo $row['officer_name'] ?></td>
          <td><?php echo $row['officer_sex'] ?></td>
          <td>Kshs <?php echo $row['officer_age'] ?></td>
        </tr>
		<?php } ?>
      </table>
	  <?php } 
	  if ($database->as_num_rows( $as_db_query ) > $max) { ?>
      <div class="pagination"> <span class="disabled"><<</span><span class="current">1</span><a href="#">2</a><a href="#">3</a><a href="#">4</a><a href="#">5</a><a href="#">6</a><a href="#">7</a>…<a href="#">10</a><a href="#">11</a><a href="#">>></a> </div>
	  <?php } ?>
    </div>
    <!-- end of column four -->
  </div>
<?php include AS_THEME."as_footer.php" ?>