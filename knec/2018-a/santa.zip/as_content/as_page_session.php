<?php
	$database = new As_Dbconn();
	$as_pageinfo = array();
	$html = '';
	$as_sessionid = isset( $_GET['as_sessionid'] ) ? $_GET['as_sessionid'] : "";
	
	switch ( $request_two ) {
		case 'new'.as_urlExt: {
				$as_pageinfo['pageTitle'] = 'New Session';
				$off_results = $database->get_results("SELECT * FROM as_officers ORDER BY officerid ASC");
				$cli_results = $database->get_results("SELECT * FROM as_clients ORDER BY clientid ASC");
				
				$officers = array();
				$clients = array();
				$times = array( 
					array ('value' => '8:00 AM', 'option' => '8:00 AM'),
					array ('value' => '9:00 AM', 'option' => '9:00 AM'),
					array ('value' => '10:00 AM', 'option' => '10:00 AM'),
					array ('value' => '11:00 AM', 'option' => '11:00 AM'),
					array ('value' => '12:00 PM', 'option' => '12:00 PM'),
					array ('value' => '13:00 PM', 'option' => '13:00 PM'),
					array ('value' => '14:00 PM', 'option' => '14:00 PM'),
					array ('value' => '15:00 PM', 'option' => '15:00 PM'),
					array ('value' => '16:00 PM', 'option' => '16:00 PM'),
					array ('value' => '17:00 PM', 'option' => '17:00 PM'),
				);
				
				$index = 0;
				foreach ( $off_results as $row ) {
					$officers[$index] = array( 'value' => $row['officerid'], 'option' => $row['officer_name'] );
					$index++;
				}
				
				$index = 0;
				foreach ( $cli_results as $row ) {
					$clients[$index] = array( 'value' => $row['clientid'], 'option' => $row['client_name'] );
					$index++;
				}
				
				$fields = array(
					'session_officer' => array(
						'label' => 'Select Officer:', 
						'type' => 'select',
						'options' => $officers,
					),
					
					'session_client' => array(
						'label' => 'Select Client:', 
						'type' => 'select',
						'options' => $clients,
					),	
					
					'session_title' => array(
						'label' => 'Session Title:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'session_description' => array(
						'label' => 'Session Description:', 
						'type' => 'textarea', 
						'tags' => 'autocomplete="off"',
					),

					'session_start' => array(
						'label' => 'Starting Time:',
						'type' => 'select',
						'options' => $times,
					),
					
					'session_end' => array(
						'label' => 'Ending Time:',
						'type' => 'select',
						'options' => $times,
					),
										
					'session_date' => array(
						'label' => 'Date of Session:',
						'type' => 'text',
						'value' => date('d/m/Y'),
					),
						
				);
				
				$buttons = array(
					'SaveItem' => 'Save and Add',
					'SaveClose' => 'Save and Close',
				);
				
				$html .= as_form_format( $fields, $buttons, as_menu_handler('sessions/new'));
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'view'.as_urlExt: {
				$as_db_query = "SELECT session_title, session_description, session_start, session_end, session_date, session_officer, session_client, officer_name, officer_mobile, officer_email, officer_location, client_name, client_mobile, client_email, client_location FROM as_sessions 
					LEFT JOIN as_officers ON as_sessions.session_officer = as_officers.officerid 
					LEFT JOIN as_clients ON as_sessions.session_client = as_clients.clientid
					WHERE sessionid = $as_sessionid";
				list( $session_title, $session_description, $session_start, $session_end, $session_date, $session_officer, $session_client, $officer_name, $officer_mobile, $officer_email, $officer_location, $client_name, $client_mobile, $client_email, $client_location) = $database->get_row( $as_db_query );
				
				$as_pageinfo['pageTitle'] = 'Session: '.$session_title;
				$as_pageinfo['pageLink'] = '<a style="float:right;" onclick="return confirm(\'Are you sure you want to delete this session from the system? \nBe careful, this action can not be reversed.\')" href="'.as_menu_handler('session/delete').'?as_sessionid='.$as_sessionid.'">DELETE THIS SESSION?</a>';
							
				$html .= '<table style="width:90%;font-size:20px;" border="1">';
				$html .= '<tr><td><b>Session Title: </b></td><td> '.$session_title.'</td></tr>';
				$html .= '<tr><td><b>Session Date:</b></td><td> '.$session_date.'</td></tr>';
				$html .= '<tr><td><b>Session Starts:</b></td><td> '.$session_start.'</td></tr>';
				$html .= '<tr><td><b>Session Ends:</b></td><td> '.$session_end.'</tr><tr></tr>';
				$html .= '<tr><td><b>Session Description:</b></td><td><p>'.$session_description.'</p></tr><tr></tr>';
				$html .= '<td valign="top"><a href="'.as_menu_handler('officers/view').'?as_officerid='.$session_officer.'"><h3>'.$officer_name.' (Client)</h3></a><table><tr>';				
				$html .= '<tr><td>Mobile: </td><td>'.$officer_mobile.'</td><tr>';
				$html .= '<tr><td>Email: </td><td>'.$officer_email.'</td><tr>';
				$html .= '<tr><td>Location: </td><td>'.$officer_location.'</td></tr></table></td>';
				$html .= '<td valign="top"><a href="'.as_menu_handler('clients/view').'?as_clientid='.$session_client.'"><h3>'.$client_name.' (Client)</h3></a><table><tr>';				
				$html .= '<tr><td>Mobile: </td><td>'.$client_mobile.'</td><tr>';
				$html .= '<tr><td>Email: </td><td>'.$client_email.'</td><tr>';
				$html .= '<tr><td>Location: </td><td>'.$client_location.'</td></tr></table>';
				$html .= '</td></tr></table>';
				
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'delete'.as_urlExt: {
				$as_pageinfo['pageContent'] = $as_pageinfo['pageTitle'] = '';
				$delete = array( 'sessionid' => $as_sessionid );
				$deleted = $database->delete( 'as_session', $delete, 1 );
				header("location: ".as_menu_handler('sessions/all') );
			}
			break;			
		default:{
			$as_pageinfo['pageLink'] = '<a style="float:right;" href="'.as_menu_handler('sessions/new').'">ADD A NEW SESSION</a>';
			
			$rows = array('sessionid', 'session_title', 'session_date', 'session_start', 'session_end' );
			$rw_check = array( 'officer_name', 'client_name' );
			$as_db_query = "SELECT sessionid, session_title, session_description, session_start, session_end, session_date, officer_name, client_name FROM as_sessions 
					LEFT JOIN as_officers ON as_sessions.session_officer = as_officers.officerid 
					LEFT JOIN as_clients ON as_sessions.session_client = as_clients.clientid 
					ORDER BY sessionid DESC";	
			$results = $database->get_results( $as_db_query );
			$as_pageinfo['pageTitle'] = 'List of Sessions ('.$database->as_num_rows( $as_db_query ).')';
			
			$theader_arr = array('ID', 'Session', 'Date', 'Starting', 'Ending', 'Officer', 'Client');
			$html .= as_table_format($theader_arr, $rows, $results, 
				as_menu_handler('sessions/view').'?as_sessionid=', 'sessionid', 'session_description', $rw_check );
			$as_pageinfo['pageContent'] = $html;
		}
	}
	
	if (as_clicked('SaveItem')) {
		as_new_session();
		header("location: ".as_menu_handler('sessions/new'));
	} else if (as_clicked('SaveClose')) {
		as_new_session();
		header("location: ".as_menu_handler('sessions/all'));
	} else {
		require_once AS_FUNC."as_paging.php";	
		include AS_THEME."as_header.php";
		echo  $as_pageinfo['pageContent'];
		include AS_THEME."as_footer.php";
	}