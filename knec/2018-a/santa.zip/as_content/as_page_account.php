<?php
	$database = new As_Dbconn();
	$as_pageinfo = array();
	$html = '';
	
	switch ( $request_two ) {
		default:{
			$as_pageinfo['pageTitle'] = 'Sign in to your Account';
			$fields = array(
				'loginname' => array(
					'label' => 'Username:',
					'type' => 'text',
				),
				
				'loginkey' => array(
					'label' => 'Password:',
					'type' => 'password',
				),
			);
			
			$buttons = array(
				'SigninNow' => 'Sign In',
			);
			
			$html .= as_form_format( $fields, $buttons, as_menu_handler('index'));
			$as_pageinfo['pageContent'] = $html;
		}
	}
	
	if (as_clicked('SigninNow')) {
		as_account_signin();
		header("location: ".as_menu_handler('index'));
	} else {
		require_once AS_FUNC."as_paging.php";	
		include AS_THEME."as_header.php";
		echo  $as_pageinfo['pageContent'];
		include AS_THEME."as_footer.php";
	}