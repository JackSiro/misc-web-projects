<?php
	$database = new As_Dbconn();
	$as_pageinfo = array();
	$html = '';
	$as_clientid = isset( $_GET['as_clientid'] ) ? $_GET['as_clientid'] : "";
	$client_sexs = array(
		array('value' => 'M', 'option' => 'Male'), 
		array('value' => 'F', 'option' => 'Female'),
	);
				
	switch ( $request_two ) {
		case 'new'.as_urlExt: {
				$as_pageinfo['pageTitle'] = 'New Client';
				
				$fields = array(
					'client_name' => array(
						'label' => 'Full Name:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'client_sex' => array(
						'label' => 'Client Sex:', 
						'type' => 'radio',
						'value' => 'M',
						'options' => $client_sexs,
					),
					
					'client_mobile' => array(
						'label' => 'Mobile Phone:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'client_email' => array(
						'label' => 'Email Address:', 
						'type' => 'text', 
						'tags' => 'autocomplete="off"',
					),
					
					'client_location' => array(
						'label' => 'Location:', 
						'type' => 'textarea', 
						'tags' => 'autocomplete="off"',
					),
					
				);
				
				$buttons = array(
					'SaveItem' => 'Save and Add',
					'SaveClose' => 'Save and Close',
				);
				
				$html .= as_form_format( $fields, $buttons, as_menu_handler('clients/new'));
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'view'.as_urlExt: {
				$as_db_query = "SELECT * FROM as_clients WHERE clientid=$as_clientid";
				list( $clientid, $client_name, $client_sex, $client_mobile, $client_email, $client_location) = $database->get_row( $as_db_query );

				$as_pageinfo['pageTitle'] = 'View Client :: '.$client_name.' ('.$client_sex.')';
				$as_pageinfo['pageLink'] = '<a style="float:right;" href="'.as_menu_handler('clients/edit').'?as_clientid='.$as_clientid.'">EDIT THIS CLIENT</a>';
				
				$html .= '<table style="width:90%;font-size:20px;">';
				$html .= '<tr><td><b>Email Address: </b></td><td style="width:30px;"><b> : </b></td><td> '.$client_email.'</tr>';
				$html .= '<tr><td><b>Mobile Phone</b></td><td><b> : </b></td><td> '.$client_mobile.'</tr>';
				$html .= '<tr><td><b>Location</b></td><td><b> : </b></td><td> '.$client_location.'</tr>';
				$html .= '</table>';
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'edit'.as_urlExt: {
				$as_db_query = "SELECT * FROM as_clients WHERE clientid=$as_clientid";
				list( $clientid, $client_name, $client_sex, $client_mobile, $client_email, $client_location) = $database->get_row( $as_db_query );

				$as_pageinfo['pageTitle'] = 'Edit Client :: '.$client_name.' ('.$client_sex.')';
				$as_pageinfo['pageLink'] = '<a style="float:right;" onclick="return confirm(\'Are you sure you want to delete this client from the system? \nBe careful, this action can not be reversed.\')" href="'.as_menu_handler('clients/delete').'?as_clientid='.$as_clientid.'">DELETE THIS CLIENT?</a>';
				
				$fields = array(
					'client_name' => array(
						'label' => 'Full Name:', 
						'type' => 'text', 
						'value' => $client_name,
						'tags' => 'autocomplete="off"',
					),
					
					'client_sex' => array(
						'label' => 'Client Sex:', 
						'type' => 'radio',
						'value' => $client_sex,
						'options' => $client_sexs,
					),
					
					'client_mobile' => array(
						'label' => 'Mobile Phone:', 
						'type' => 'text',
						'value' => $client_mobile, 
						'tags' => 'autocomplete="off"',
					),
					
					'client_email' => array(
						'label' => 'Email Address:', 
						'type' => 'text', 
						'value' => $client_email,
						'tags' => 'autocomplete="off"',
					),
					
					'client_location' => array(
						'label' => 'Location:', 
						'type' => 'text', 
						'value' => $client_location,
						'tags' => 'autocomplete="off"',
					),
					
				);
				
				$buttons = array(
					'UpdateItem' => 'Update Only',
					'UpdateClose' => 'Update and Close',
				);
				
				$html .= as_form_format( $fields, $buttons, as_menu_handler('clients/view').'?as_clientid='.$as_clientid);
				$as_pageinfo['pageContent'] = $html;
			}
			break;
		case 'delete'.as_urlExt: {
				$as_pageinfo['pageContent'] = $as_pageinfo['pageTitle'] = '';
				$delete = array( 'clientid' => $as_clientid );
				$deleted = $database->delete( 'as_client', $delete, 1 );
				header("location: ".as_menu_handler('clients/all') );
			}
			break;			
		default:{
			$as_pageinfo['pageLink'] = '<a style="float:right;font-size: 25px;" href="'.as_menu_handler('clients/new').'">+ NEW CLIENT</a>';
			
			$rows = array('client_name', 'client_mobile', 'client_email', 'client_location' );
			$as_db_query = "SELECT * FROM as_clients ORDER BY clientid DESC";	
			$results = $database->get_results( $as_db_query );
			$as_pageinfo['pageTitle'] = 'List of Clients ('.$database->as_num_rows( $as_db_query ).')';
			$theader_arr = array('Name', 'Mobile', 'Email', 'Location');
			$html .= as_table_format($theader_arr, $rows, $results, 
				as_menu_handler('clients/view').'?as_clientid=', 'clientid' );
			$as_pageinfo['pageContent'] = $html;
		}
	}
	
	if (as_clicked('SaveItem')) {
		as_new_client();
		header("location: ".as_menu_handler('clients/new'));
	} else if (as_clicked('SaveClose')) {
		as_new_client();
		header("location: ".as_menu_handler('clients/all'));
	} else if (as_clicked('UpdateItem')) {
		as_edit_client($as_clientid);
		as_menu_handler('clients/view').'?as_clientid='.$as_clientid;
	} else if (as_clicked('UpdateClose')) {
		as_edit_client($as_clientid);
		header("location: ".as_menu_handler('clients/all'));
	} else {
		require_once AS_FUNC."as_paging.php";	
		include AS_THEME."as_header.php";
		echo  $as_pageinfo['pageContent'];
		include AS_THEME."as_footer.php";
	}