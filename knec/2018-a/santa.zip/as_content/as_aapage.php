<?php
/*
	
	File: as_functions/as_base.php
	Description: Sets up AppSmata environment, plus many globally useful functions
*/
	function as_get_request_content()
	{
		if (as_to_override(__FUNCTION__)) { $args=func_get_args(); return as_call_override(__FUNCTION__, $args); }
		
		$requestlower = strtolower(as_request());
		$requestparts = as_request_parts();
		$request_one = strtolower($requestparts[0]);
		if (count($requestparts)>1) {
			$request_two = strtolower($requestparts[1]);
		} else $request_two = "";
		
		$as_loginid = isset( $_SESSION['santa_userid'] ) ? $_SESSION['santa_userid'] : "";

		if (empty($as_loginid)) {
			$as_content = require( "as_page_account.php" );
			exit();
		}
		
		$as_request = isset( $_GET['as_request'] ) ? $_GET['as_request'] : "";
		
		switch ( $request_one ) {
			case 'index'.as_urlExt:	
				$as_content = require( "as_page_session.php" );
				break;
			case 'options'.as_urlExt:	
				$as_content = require( "as_page_options.php" );
				break;
			case 'users':
			case 'users'.as_urlExt:
				$as_content = require( "as_page_users.php" );
				break;
			case 'sessions':
			case 'sessions'.as_urlExt:
				$as_content = require( "as_page_session.php" );
				break;
			case 'clients': 
			case 'clients'.as_urlExt: 
				$as_content = require( "as_page_client.php" );
				break;
			case 'officers': 
			case 'officers'.as_urlExt: 
				$as_content = require( "as_page_officer.php" );
				break;
			case 'account': 
				switch ( $request_two ) {	
					case 'logout'.as_urlExt:	
						$as_content = as_logout();
						break;	
					case 'login'.as_urlExt:			
						$as_content = require( "as_account_signin.php" );
						break;
					case 'register'.as_urlExt:			
						$as_content = require( "as_account_signup.php" );
						break;	
					case 'forgotten'.as_urlExt:	
						$as_content = require( "as_account_forgotten.php" );
						break;
					case 'username'.as_urlExt:	
						$as_content = require( "as_account_username.php" );
						break;	
					case 'account'.as_urlExt:	
						$as_content = require( "as_account_account.php" );
						break;			
					default:		
						$as_content = require( "as_page_home.php" );
				}			
				break;
			default:		
				$as_content = require( "as_page_session.php" );
				//$as_content = as_check_requested_content($request_one);
		}
		
		return $as_content;
	}

	global $as_usage;
	require_once AS_FUNC.'as_users.php';
	require_once AS_FUNC."as_posting.php";
	
	function client_delete() {
		$database = new As_Dbconn();
		$as_clientid = isset( $_GET['as_clientid'] ) ? $_GET['as_clientid'] : "";
		$delete = array(
			'clientid' => $as_clientid,
		);
		$deleted = $database->delete( 'as_clients', $delete, 1 );
		header('Location: '.as_siteUrl.'admin/client_all'.as_urlExt );
	}

	function officer_delete() {
		$database = new As_Dbconn();
		$as_officerid = isset( $_GET['as_officerid'] ) ? $_GET['as_officerid'] : "";
		$delete = array(
			'officerid' => $as_officerid,
		);
		$deleted = $database->delete( 'as_officers', $delete, 1 );
		header('Location: '.as_siteUrl.'admin/officer_all'.as_urlExt );
	}

	function accessory_delete() {
		$database = new As_Dbconn();
		$as_accessoryid = isset( $_GET['as_accessoryid'] ) ? $_GET['as_accessoryid'] : "";
		$delete = array(
			'accessoryid' => $as_accessoryid,
		);
		$deleted = $database->delete( 'as_accessorys', $delete, 1 );
		header('Location: '.as_siteUrl.'admin/accessory_all'.as_urlExt );
	}

	as_get_request_content();
	
?>