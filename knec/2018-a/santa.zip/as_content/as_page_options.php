<?php
	$database = new As_Dbconn();
	$as_pageinfo = array();
	$html = '';
	
	switch ( $request_two ) {
		default:{
			$as_pageinfo['pageTitle'] = 'Manage Site Options';
			$fields = array(
				'as_sitename' => array(
					'label' => 'Site Name:',
					'type' => 'text',
					'value' => as_get_option('as_sitename'),
				),
				
			);
			
			$buttons = array(
				'SaveOptions' => 'Save Options',
			);
			
			$html .= as_form_format( $fields, $buttons, as_menu_handler('index'));
			$as_pageinfo['pageContent'] = $html;
		}
	}
	
	if (as_clicked('SigninNow')) {
		as_set_option('as_sitename', as_post_text('as_sitename'), 1);
		header("location: ".as_menu_handler('options'));
	} else {
		require_once AS_FUNC."as_paging.php";	
		include AS_THEME."as_header.php";
		echo  $as_pageinfo['pageContent'];
		include AS_THEME."as_footer.php";
	}