<?php	
		
	function as_navigation($request){
		$myloginid = isset( $_SESSION['santa_userid'] ) ? $_SESSION['santa_userid'] : "";
		
		$navigation = array();
		$navigation['home'] = array('label' => 'Home', 'url' => '.');
		if ( $myloginid ) {
			$navigation['sessions'] = array('label' => 'Sessions', 'url' => 'sessions');
			$navigation['officers'] = array('label' => 'Officers', 'url' => 'officers');
			$navigation['clients'] = array('label' => 'Clients', 'url' => 'clients');
			$navigation['options'] = array('label' => 'Site Options', 'url' => 'options');
			$navigation['logout'] = array('label' => 'Logout?', 'url' => 'account/logout');
			
		} else {
			$navigation['login'] = array('label' => 'Login', 'url' => 'account/login');
		}
			
		if (isset($navigation[$request])) $navigation[$request]['selected']=true;
		return $navigation;
	}
	
	function as_navigate($request) {
		$navi = as_navigation($request);
		$html = '';
		foreach ($navi as $k => $a){
			if ( $k != 'home'){
				$html .= '<li><a '.(($request==$k) ? 'class="selected" ': '').'href="'.as_menu_handler($a['url']).'">'.$a['label'].'</a></li>'."\n\t\t";
			} else {
				$html .= '<li><a '.(empty($request) ? 'class="selected" ': '').'href=".">Home</a></li>'."\n\t\t";
			}
		}
		return $html;
	}
	
	
	function as_table_format( $theader_arr, $row_arr, $tbody_arr, $onclick = false, $rowid = false, $descript = false, $rw_check = false ){
		$html = '<table class="tt_tb">'."\n\t";
		$html .= '<thead><tr>'."\n\t";
		foreach( $theader_arr as $hrow ) {
			$html .= '<th>'.$hrow.'</th>'."\n\t";
		}
		$html .= '</tr></thead><tbody>'."\n\t";
        
		foreach( $tbody_arr as $row ) {
		    $html .= '<tr'.(isset($onclick) ? ' title="Click on this item to edit or view" onclick="location=\''.$onclick.$row[$rowid].'\'"' : '' ).'>'."\n\t";
			foreach( $row_arr as $row_vl ) $html .= '<td>'.$row[$row_vl].'</td>'."\n\t";
			if (!empty($rw_check)) {
				foreach( $rw_check as $check => $td ) {
					$html .= '<td>'.$row[$td].'</td>'."\n\t";
				}
			}
		    $html .= '</tr>'."\n\t";
		}
		$html .= '</tbody></table>'."\n\t";
		return $html;
	}
	
	function as_form_format( $fields, $buttons, $actionurl, $hidden = false ){
		$html = '<div id="general_form">'."\n\t";
		$html .= '<form method="post" action="'.$actionurl.'">'."\n\t";
		$html .= '<div class="form_settings">'."\n\t";
		if (count($fields)) {
			foreach($fields as $name => $field) { 
				$html .= '<label>'.as_html($field['label']).'</label>'."\n\t\t<p>";	
				switch ( $field['type'] ) {
					case 'radio':
						$html .= as_form_radio($name, $field);
						break;
					case 'select':
						$html .= as_form_select($name, $field);
						break;
					case 'textarea': 
						$html .= as_form_textarea($name, $field);
						break;
					default: 
						$html .= as_form_default($name, $field);
				}
				$html .= '</p>'."\n\t\t";
			}
		}
		foreach ($buttons as $name => $value)
			$html .='<p><br><input type="submit" name="'.as_html($name).'" value="'.as_html($value).'" class="submit_btn"/></p>'."&nbsp\n\t\t";
		if (!empty($hidden)) {
			foreach ($hidden as $name => $value)
				$html .='<input type="hidden" name="'.as_html($name).'" value="'.as_html($value).'" />'."\n\t\t";
		}
		$html .= '</div>'."\n\t";
		$html .= '</form>'."\n\t";
		$html .= '</div>'."\n\t";
		return $html;
	}
	
	function as_form_radio($name, $field) {
		$html = "\n\t\t";
		foreach ($field['options'] as $opt) {
			$html .= '<input type="radio" name="'.$name.'"' . @$field['tags'] . ' value="' . $opt['value'] . '"' . (($opt['value'] == @$field['value']) ? ' checked' : '') . '/> ' . $opt['option']."\n\t\t";
		}
		return $html;
	}

	function as_form_select($name, $field) {
		$html = '<select name="'.$name.'"' . (isset($field['tags']) ? $field['tags'] : '') . ' class="input_field">'."\n\t\t";
		$html .= '<option value="0"></option>'."\n\t\t";
		foreach ($field['options'] as $opt) {
			$html .= '<option value="' . $opt['value'] . '"' . (($opt['value'] == @$field['value']) ? ' selected' : '') . '>' . $opt['option'] . '</option>'."\n\t\t";
		}
		return $html.'</select>'."\n\t\t";
	}
	
	function as_form_textarea($name, $field) {
		return '<textarea name="'.$name.'"'.(isset($field['tags']) ? $field['tags'] : '').' class="input_field" >'.(isset($field['value']) ? $field['value'] : '').'</textarea>'."\n\t\t";
	}
	
	function as_form_default($name, $field) {
		return '<input type="'.$field['type'].'" name="'.$name.'"" value="'.(isset($field['value']) ? $field['value'] : '').'"'.(isset($field['tags']) ? $field['tags'] : '').' class="input_field" />'."\n\t\t";
	}
	
	function as_error_message()
	{
		if( isset($_SESSION['AS_ERRMSG_ARR']) && is_array($_SESSION['AS_ERRMSG_ARR']) && count($_SESSION['AS_ERRMSG_ARR']) >0 ) {
		$html = '<div class="col-error panel panel-default">
			<ul class="panel-body as_list">';							
			foreach($_SESSION['AS_ERRMSG_ARR'] as $as_error_msg) { 
				$html .= '<li class="as_error" id="as_error">'.$as_error_msg.'</li>';
			}
			$html .= '</ul>
		  </div>';
			unset($_SESSION['AS_ERRMSG_ARR']); 
			return $html;
		} 
	}
	
	function as_success_message()
	{
		if( isset($_SESSION['AS_SUCCMSG_ARR']) && is_array($_SESSION['AS_SUCCMSG_ARR']) && count($_SESSION['AS_SUCCMSG_ARR']) >0 ) { 
		$html = '<div class="col-success panel panel-default">
			<ul class="panel-body as_list">';						
			foreach($_SESSION['AS_SUCCMSG_ARR'] as $as_succ_msg) { 
				$html .= '<li class="as_success" id="as_success">'.$as_succ_msg.'</li>';
			}
			$html .= '</ul>
		  </div>';
			unset($_SESSION['AS_SUCCMSG_ARR']);
			return $html;
		}
	}
	