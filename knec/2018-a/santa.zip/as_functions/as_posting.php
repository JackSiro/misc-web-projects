<?php
	// POSTING FUNCTIONS
	// Begin Posting Functions 

	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}

	function as_str_tags($string){
		$slag6 = trim($string);
		$slag5 = strtolower($slag6);
		$slag4 = preg_replace("/[\s-]+/", "-", $slag5);
		$slag3 = preg_replace('/[^,;a-zA-Z0-9_-]|[,;]$/s', '', $slag4);
		$slag2 = preg_replace("/\_/", "-", $slag3);
		$slag1 = preg_replace("/\,-/", ", ", $slag2);
		$slag = preg_replace("/\-,/", ",", $slag1);
		return $slag;
	}
	
	function as_str_text($string) {
        $text4 = str_replace('"', '+', $string);
		$text3 = str_replace('<br />', '$', $text4);
		$text2 = str_replace("'", "^", $text3);
		$text1 = strip_tags($text2);	
		$text = trim($text1);			
		return $text;
	}
	
	function is_english_used($string) {
		if (strlen($str) != strlen(utf8_decode($str))) {
			return false;
			} else {
				return true;
			}
	}
	
	function as_slug_this($content) {
		return preg_replace("/-$/","",preg_replace('/[^a-z0-9]+/i', "-", strtolower($content)));
	}
	
	function as_slug_is(){
		/*if(empty(as_post_text('slug')) {
		    $as_slug = as_post_text('slug');
		} else $as_slug = as_slug_this(as_post_text('title');
		*/
	}
	function as_new_client(){
		$database = new As_Dbconn();
		$Item_Details = array(	
			'client_name' 		=> as_post_text('client_name'),
			'client_sex' 		=> as_post_text('client_sex'),
			'client_mobile' 	=> as_post_text('client_mobile'),
			'client_email' 		=> as_post_text('client_email'),
			'client_location' 	=> as_post_text('client_location'),
			'client_posted' 	=> date('Y-m-d H:i:s'),
			'client_postedby' 	=> 1,
		);
		$add_query = $database->as_insert( 'as_clients', $Item_Details );
	}
	
	function as_edit_client($clientid){
		$database = new As_Dbconn();			
		$Item_Details = array(
			'client_name' 		=> as_post_text('client_name'),
			'client_sex' 		=> as_post_text('client_sex'),
			'client_mobile' 	=> as_post_text('client_mobile'),
			'client_email' 		=> as_post_text('client_email'),
			'client_location' 	=> as_post_text('client_location'),
			'client_updated' 	=> date('Y-m-d H:i:s'),
			'client_updatedby' 	=> "1",
		);
		$where_clause = array('clientid' => $clientid);
		$updated = $database->as_update( 'as_clients', $Item_Details, $where_clause, 1 );
	}
	
	function as_officer_session($officerid) {
		$database = new As_Dbconn();
		$as_db_query = "SELECT officer_session FROM as_officers WHERE officerid=$officerid";
		list( $officer_session) = $database->get_row( $as_db_query );
		return $officer_session;
	}
	
	function as_allocate_session($officerid, $pay){
		$database = new As_Dbconn();
		$Item_Details = array(
			'officer_session' 	=> $pay,
		);
		$where_clause = array('officerid' => $officerid);
		$updated = $database->as_update( 'as_officers', $Item_Details, $where_clause, 1 );
	}
	
	function as_allocate_client($clientid, $officerid){
		$database = new As_Dbconn();
		$Item_Details = array(
			'client_name' 	=> $officerid,
		);
		$where_clause = array('clientid' => $clientid);
		$updated = $database->as_update( 'as_clients', $Item_Details, $where_clause, 1 );
	}
	
	function as_new_officer(){
		$database = new As_Dbconn();
		$Item_Details = array(	
			'officer_name' 		=> as_post_text('officer_name'),
			'officer_sex' 		=> as_post_text('officer_sex'),
			'officer_mobile' 	=> as_post_text('officer_mobile'),
			'officer_email' 		=> as_post_text('officer_email'),
			'officer_location' 	=> as_post_text('officer_location'),
			'officer_posted' 	=> date('Y-m-d H:i:s'),
			'officer_postedby' 	=> 1,
		);
		$add_query = $database->as_insert( 'as_officers', $Item_Details );
	}
	
	function as_edit_officer($officerid){
		$database = new As_Dbconn();			
		$Item_Details = array(
			'officer_name' 		=> as_post_text('officer_name'),
			'officer_sex' 		=> as_post_text('officer_sex'),
			'officer_mobile' 	=> as_post_text('officer_mobile'),
			'officer_email' 		=> as_post_text('officer_email'),
			'officer_location' 	=> as_post_text('officer_location'),
			'officer_updated' 	=> date('Y-m-d H:i:s'),
			'officer_updatedby' 	=> "1",
		);
		$where_clause = array('officerid' => $officerid);
		$updated = $database->as_update( 'as_officers', $Item_Details, $where_clause, 1 );
	}
	
	function as_new_session(){
		$database = new As_Dbconn();
		$Item_Details = array(
			'session_officer'		=> as_post_text('session_officer'),
			'session_client'		=> as_post_text('session_client'),
			'session_title'			=> as_post_text('session_title'),
			'session_description'	=> as_post_text('session_description'),
			'session_start'			=> as_post_text('session_start'),
			'session_end'			=> as_post_text('session_end'),
			'session_date'			=> as_post_text('session_date'),
			'session_created' 		=> date('Y-m-d H:i:s'),
			'session_createdby' 		=> 1,
		);
		$add_query = $database->as_insert( 'as_sessions', $Item_Details );
		return $database->as_db_lastid();
	}
	
	function as_edit_session($sessionid){
		$database = new As_Dbconn();
		$Item_Details = array(
			'session_officer'		=> as_post_text('session_officer'),
			'session_client'		=> as_post_text('session_client'),
			'session_title'		=> as_post_text('session_title'),
			'session_description'		=> as_post_text('session_description'),
			'session_start'		=> as_post_text('session_start'),
			'session_end'		=> as_post_text('session_end'),
			'session_date'		=> as_post_text('session_date'),
			'session_posted' 	=> date('Y-m-d H:i:s'),
			'session_postedby' 	=> 1,
		);
		$where_clause = array('sessionid' => $sessionid);
		$updated = $database->as_update( 'as_sessions', $Item_Details, $where_clause, 1 );
	}
	