<?php
	
	$database = new As_Dbconn();
	
	//officer_name, officer_sex, officer_mobile, officer_email, officer_location
	$As_Table_Details = array(	
		'officerid int(10) unsigned NOT NULL AUTO_INCREMENT',
		'officer_name varchar(100) DEFAULT NULL',
		'officer_sex varchar(100) DEFAULT NULL',
		'officer_mobile varchar(100) DEFAULT NULL',
		'officer_email varchar(100) DEFAULT NULL',
		'officer_location varchar(100) DEFAULT NULL',
		'officer_posted datetime DEFAULT NULL',
		'officer_postedby int(10) unsigned DEFAULT 0',
		'officer_updated date DEFAULT NULL',
		'officer_updatedby int(10) unsigned DEFAULT NULL',
		'PRIMARY KEY (officerid)',
		);
	$add_query = $database->as_table_exists_create( 'as_officers', $As_Table_Details ); 
	
	//client_name, client_sex, client_mobile, client_email, client_location
	$As_Table_Details = array(	
		'clientid int(10) unsigned NOT NULL AUTO_INCREMENT',
		'client_name varchar(100) DEFAULT NULL',
		'client_sex varchar(100) DEFAULT NULL',
		'client_mobile varchar(100) DEFAULT NULL',
		'client_email varchar(100) DEFAULT NULL',
		'client_location varchar(100) DEFAULT NULL',
		'client_postedby int(10) unsigned DEFAULT NULL',
		'client_posted datetime DEFAULT NULL',
		'client_updatedby int(10) unsigned DEFAULT NULL',
		'client_updated datetime DEFAULT NULL',
		'PRIMARY KEY (clientid)',
		);
	$add_query = $database->as_table_exists_create( 'as_clients', $As_Table_Details ); 
	
	//sessionid, session_officer, session_client, session_title, session_description, session_start, session_end, session_date
	$As_Table_Details = array(
		'sessionid int(11) NOT NULL AUTO_INCREMENT',
		'session_officer int(11) DEFAULT NULL',
		'session_client int(11) DEFAULT NULL',
		'session_title varchar(100) NOT NULL',
		'session_description varchar(100) NOT NULL',
		'session_start varchar(50) NOT NULL',
		'session_end varchar(50) NOT NULL',
		'session_date varchar(50) NOT NULL',
		'session_createdby int(10) unsigned DEFAULT NULL',
		'session_created datetime DEFAULT NULL',
		'session_updatedby int(10) unsigned DEFAULT NULL',
		'session_updated datetime DEFAULT NULL',
		'PRIMARY KEY (sessionid)',
		);
	$add_query = $database->as_table_exists_create( 'as_sessions', $As_Table_Details ); 
	
	$As_Table_Details = array(	
		'optionid int(11) NOT NULL AUTO_INCREMENT',
		'option_title varchar(100) NOT NULL',
		'option_content varchar(2000) NOT NULL',
		'option_createdby int(10) unsigned DEFAULT NULL',
		'option_created datetime DEFAULT NULL',
		'option_updatedby int(10) unsigned DEFAULT NULL',
		'option_updated datetime DEFAULT NULL',
		'PRIMARY KEY (optionid)',
		);
	$add_query = $database->as_table_exists_create( 'as_site_options', $As_Table_Details ); 
	
	$As_Table_Details = array(	
		'userid int(11) NOT NULL AUTO_INCREMENT',
		'user_name varchar(50) NOT NULL',
		'user_fname varchar(50) NOT NULL',
		'user_lname varchar(50) NOT NULL',
		'user_mobile varchar(50) NOT NULL',
		'user_sex int(10) NOT NULL DEFAULT 1',
		'user_password text NOT NULL',
		'user_email varchar(200) NOT NULL',
		'user_group int(10) NOT NULL DEFAULT 0',
		'user_level int(10) NOT NULL DEFAULT 0',
		'user_avatar varchar(50) NOT NULL DEFAULT "user_default.jpg"',
		'user_location varchar(100) NOT NULL',
		'user_joined datetime DEFAULT NULL',
		'user_updated datetime DEFAULT NULL',
		'user_lastseen datetime DEFAULT NULL',
		'PRIMARY KEY (userid)',
		);
	$add_query = $database->as_table_exists_create( 'as_users', $As_Table_Details ); 
	