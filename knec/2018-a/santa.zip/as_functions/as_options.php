<?php
	
	// OPTIONS FUNCTIONS
	// Begin Options Functions
	
	function as_timeago($ptime) {
		if ($ptime) 
		{
			$estimate_time = time() - strtotime($ptime);
			if ($estimate_time < 1) {
				return 'just now';
			}
			$condition = array(
						12 * 30 * 24 * 60 * 60	 => 'year',
						30 * 24 * 60 * 60		 => 'month',
						24 * 60 * 60			 => 'day',
						60 * 60					 => 'hour',
						60						 => 'minute',
						1						 => 'second',
			);
			foreach($condition as $secs => $str) {
				$d = $estimate_time / $secs;
				if ($d >= 1) {
					$r = round($d);
					return $r.' '.$str.($r > 1 ? 's' : '').' ago';
				}
			}
		} else return "";
	}
	
	function as_timeago_now($ptime) {
		if ($ptime) 
		{
			$estimate_time = time() - strtotime($ptime);
			if ($estimate_time < 1) {
				return 'just now';
			}
			$condition = array(
						12 * 30 * 24 * 60 * 60	 => 'yr',
						30 * 24 * 60 * 60		 => 'mon',
						24 * 60 * 60			 => 'day',
						60 * 60					 => 'hr',
						60						 => 'min',
						1						 => 'sec',
			);
			foreach($condition as $secs => $str) {
				$d = $estimate_time / $secs;
				if ($d >= 1) {
					$r = round($d);
					return $r.' '.$str.($r > 1 ? 's' : '').' ago';
				}
			}
		} else return "";
	}
	
	function as_online_last($ptime) {
		if (strtotime($ptime) <= 0) {
			return 'never';
		}
		
		$estimate_time = time() - strtotime($ptime);
		if ($estimate_time < 60) {
			return 'online';
		}
		$condition = array(
					12 * 30 * 24 * 60 * 60	 => 'year',
					30 * 24 * 60 * 60		 => 'month',
					24 * 60 * 60			 => 'day',
					60 * 60					 => 'hour',
					60						 => 'minute',
					1						 => 'second',
		);
		foreach($condition as $secs => $str) {
			$d = $estimate_time / $secs;
			if ($d >= 1) {
				$r = round($d);
				return $r.' '.$str.($r > 1 ? 's' : '').' ago';
			} 
		}
	}
	
	function as_menu_handler($url) {
		return as_siteUrl.$url.as_urlExt;
	}
	
	function as_users_sex($val){
		switch ( $val ) {
			case 1:
				return 'M';
				break;
			case 2:
				return 'F';
				break;
			default:
				return 'O';
		}
	}
	
	function as_users_sexfull($val){
		switch ( $val ) {
			case 1:
				return 'Male';
				break;
			case 2:
				return 'Female';
				break;
			default:
				return 'Other';
		}
	}
	
	function as_users_grp($grp){
		switch ( $grp ) {
			case 1:
				return 'Administrator';
				break;
			case 2:
				return 'Client Member';
				break;
			default:
				return 'Normal Member';
		}
	}
	
	function as_is_homepage($val){
		switch ( $val ) {
			case 1:
				return true;
				break;
			default:
				return false;
		}
	}
	
	function as_get_itemState($val){
		switch ( $val ) {
			case 3:
				return '<span class="label label-danger">Trashed</span>';
				break;
			case 2:
				return '<span class="label label-warning">Unpublished</span>';
				break;
			case 1:
				return '<span class="label label-info">Published</span></>';
				break;
			default:
				return '<span class="label label-success">Draft</span>';
		}
	}
	
	function as_users_lvl($lev) {
		switch ( $lev ) {
			case 5:
				return 'Super-Admin';
				break;
			case 4:
				return 'Admin';
				break;
			case 3:
				return 'Manager';
				break;
			case 2:
				return 'Expert';
				break;
			case 1:
				return 'Editor';
				break;
			default:
				return 'User';
		}
	}
			
    function as_select_songbooks(){
		$database = new As_Dbconn();
		$as_db_query = "SELECT * FROM as_clients";
		$results = $database->get_results( $as_db_query );		
		foreach( $results as $row )
		{
			echo '<option value="'.$row['clientid'].'"> '.$row['client_title'].' </option>';		                            
		}				
	}
	
	function as_songclient_scount($clientid)
	{
		$database = new As_Dbconn();
		$results = $database->get_results('SELECT scount FROM as_clients WHERE clientid=$clientid');
		return isset($results[0]) ? $results[0] : null;
	}
		
	function as_select_pages(){
		$database = new As_Dbconn();
		$as_db_query = "SELECT * FROM as_page WHERE page_state =1";
		$results = $database->get_results( $as_db_query );
        foreach( $results as $row ) 
		{
			echo '<option value="'.$row['pageid'].'"> '.$row['page_title'].' </option>';		                            
		}	
	}
	
	function getDaySufEN($day) {
		switch ($day) {
	        case 1:  return $day+"st";
	        case 2:  return $day+"nd";
	        case 3:  return $day+"rd";
	        case 21:  return $day+"st";
	        case 22:  return $day+"nd";
	        case 23:  return $day+"rd";
	        case 31:  return $day+"st";
	        default: return $day+"th";
	    }
	}
	
	function getMonSufEN($mon) {
		switch ($mon) {
	        case 1:  return "jan";
	        case 2:  return "feb";
	        case 3:  return "mar";
	        case 4:  return "apr";
	        case 5:  return "may";
	        case 6:  return "jun";
	        case 7:  return "jul";
	        case 8:  return "aug";
	        case 9:  return "sep";
	        case 10:  return "oct";
	        case 11:  return "nov";
	        case 12:  return "dec";
	        default: return "";
	    }
	}
	
    function as_select_menu_menuitems(){
		$database = new As_Dbconn();
		$as_db_query = "SELECT * FROM as_menu where menu_state=1";
		$results = $database->get_results( $as_db_query );
		foreach( $results as $row )
		{
			echo '<option value="'.$row['menuid'].'"> '.$row['menu_title'].' </option>';		                            
		}				
	}
	
	function as_selected_menu_menuitems($menu){
		$database = new As_Dbconn();
		$as_db_query = "SELECT * FROM as_menu where menu_state=1";
		$results = $database->get_results( $as_db_query );
		foreach( $results as $row )
		{
			echo '<option value="'.$row['menuid'].'" ';
			if ($row['menuid'] == $menu) echo 'selected';
			echo '> '.$row['menu_title'].' </option>';		                            
		}
	}
	
	function as_type_of_link($ltype){
		if ($ltype == 1) {
			return "Normal Link";
		} else if ($ltype == 2) {
			return "External Link";
		} else if ($ltype == 3) {
			return "Page Link";
		}
	}
	
	function as_type_of_linkshow($ltype, $link){
		if ($ltype == 1) {
			return as_siteUrl.$link.as_urlExt;
		} else if ($ltype == 2) {
			return $link;
		} else if ($ltype == 3) {
			return as_siteUrl.$link.as_urlExt;
		}
	}
	
	function as_total_saleitems(){
		$as_db_query = "SELECT * FROM as_saleitem";
		$database = new As_Dbconn();
		return $database->as_num_rows( $as_db_query );
	}
		
	function as_total_users(){
		$as_db_query = "SELECT * FROM as_users";
		$database = new As_Dbconn();
		return $database->as_num_rows( $as_db_query );		
	}
          	
	function as_total_errors(){
		$linecount = 0;
		$myfile = fopen("as_error_logs.txt", "r");
		while(!feof($myfile))
		{
			$line = fgets($myfile);
			$linecount++; 			
		}
		fclose($myfile);
		return $linecount;
	}
	
	function as_total_songs_lang($lang){
		$as_db_query = "SELECT * FROM as_song WHERE officer_lang='$lang'";
		$database = new As_Dbconn();
		return $database->as_num_rows( $as_db_query );
	}
	
	function as_total_songs(){
		$as_db_query = "SELECT * FROM as_officers";
		$database = new As_Dbconn();
		return $database->as_num_rows( $as_db_query );
	}
	
	function as_total_songbooks(){
		$as_db_query = "SELECT * FROM as_clients";
		$database = new As_Dbconn();
		return $database->as_num_rows( $as_db_query );
	}
	
	function as_menu_name($menuid){		
		$as_db_query = "SELECT * FROM as_menu WHERE menuid = '$menuid'";
		$database = new As_Dbconn();
		if( $database->as_num_rows( $as_db_query ) > 0 ) {
			list( $menuid, $menu_title, $menu_slag) = $database->get_row( $as_db_query );
		} 
		return $menu_title;
	}
	
	function as_usersnames($userid){		
		$database = new As_Dbconn();
		$results = $database->get_results("SELECT CONCAT_WS(' ', user_fname, user_lname) FROM as_users WHERE userid=$userid");		
		return isset($results[0]) ? $results[0] : null;
	}
	
	function as_officer_postedby($userid){		
		if ($userid == 0) return "Public Domain";
		else as_usersnames($userid);
	}
	
	function as_songclient_name($clientid) {
		$database = new As_Dbconn();
		$results = $database->get_row("SELECT client_title FROM as_clients WHERE clientid=$clientid");
		return isset($results[0]) ? $results[0] : null;
	}

	function as_songclient_code($clientid) {
		$database = new As_Dbconn();
		$results = $database->get_row("SELECT client_code FROM as_clients WHERE clientid=$clientid");
		return isset($results[0]) ? $results[0] : null;
	}

	function as_select_page(){
		$as_db_query = "SELECT * FROM as_page WHERE page_state=1";
		$database = new As_Dbconn();		
		$results = $database->get_results( $as_db_query );
		foreach( $results as $row )
		{
			echo "<option value='".$row['pageid']."'>".$row['page_title']."</option>";		                            
		}	
	}
	
	function as_select_client(){
		$as_db_query = "SELECT * FROM as_users";
		$database = new As_Dbconn();		
		$results = $database->get_results( $as_db_query );
		foreach( $results as $row )
		{
			echo "<option value='".$row['userid']."'>".$row['user_fname']." ".$row['user_lname']."</option>";		                            
		}	
	}
	
	function as_confirmed($concode) {
	  if ($concode == 3571240144) return "";
	}
	
	function as_show_error($content){
		$as_errmsg_arr[] = $content;
		$as_errflag = true;
		$_SESSION['AS_ERRMSG_ARR'] = $as_errmsg_arr;
	}
	
	function as_show_success($content){
		$as_succmsg_arr[] = $content;
		$as_succflag = true;
		$_SESSION['AS_SUCCMSG_ARR'] = $as_succmsg_arr;
	}
	
	function as_setLink($pagelink)
	{
		return as_siteUrl.$pagelink.as_urlExt;
	}
	
	function as_select_form($value, $option, $optionvl){
		return '<option value="'.$optionvl.'"'.(($optionvl == $value) ? ' selected' : '').'>'.$option.'</option>'."\n\t\t\t";
	}
	