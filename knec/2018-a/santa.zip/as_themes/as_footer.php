		</div>
		<div id="footer">
      Copyright &copy; 2018 <?php echo $sitename ?>
    </div>
  </div>
</body>
</html>
