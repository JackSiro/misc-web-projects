<?php
	$sitename = as_get_option('as_sitename');
	
	$pageTitle = (isset( $as_pageinfo['pageTitle'] ) ? $as_pageinfo['pageTitle'] : "")." - ".$sitename;
	$pageAdminTitle = (isset( $as_pageinfo['pageTitle'] ) ? $as_pageinfo['pageTitle'] : "")." - ".$sitename." | Admin";
	$pageAction = isset( $as_pageinfo['pageAction'] ) ? $as_pageinfo['pageAction'] : "Home";
    $pageKeywords = isset( $as_pageinfo['siteKeywords'] ) ? $as_pageinfo['siteKeywords'] : as_get_option('as_keywords');
    $pageDescription = isset( $as_pageinfo['siteDescription'] ) ? $as_pageinfo['siteDescription'] : as_get_option('as_description');
    
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo $pageTitle ?></title>
	<meta name="keywords" content="<?php echo $pageKeywords ?>">
	<meta name="description" content="<?php echo $pageDescription ?>">
	<link href="<?php echo as_base_url() ?>as_themes/style/style.css" rel="stylesheet" type="text/css" title="style" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <h1><a href="index.php"><?php echo $sitename ?></a></</h1>
          <h2>Simple. Contemporary. Convinient.</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <?php echo as_navigate( $request_one ) ?>
        </ul>
      </div>
	  <div id="site_content">
	  <h2><?php echo $as_pageinfo['pageTitle']; 
			if (array_key_exists('pageLink', $as_pageinfo))
				echo $as_pageinfo['pageLink'];
			?></h2>