<?php 
	$studentid = $results['student'];
	$as_db_query = "SELECT * FROM as_student WHERE studentid = '$studentid'";
	$database = new As_Dbconn();
	if( $database->as_num_rows( $as_db_query ) > 0 ) {
	list( $studentid, $student_admission, $student_class, $student_name, $student_course, $student_fee, $student_gender, $student_class, $student_img) = $database->get_row( $as_db_query );
}
		
?>
<?php include AS_THEME."as_header.php"; ?>
	<div id="site_content">
	  <div id="content">
        <div>
		  <h1>Edit a Student <a style="float:right;" href="index.php?action=student_delete&&as_studentid=<?php echo $studentid ?>" onclick="return confirm('Are you sure you want to delete: <?php echo $student_name ?> from the system? \nBe careful, this action can not be reversed.')">Delete Student</a></h1>
			<div student="main_content">
				<form role="form" method="post" name="PostStudent" action="index.php?action=student_view&&as_studentid=<?php echo $studentid ?>" >
                <p><span>Full Name</span><input type="text" name="name" value="<?php echo $student_name ?>"></p>
				<p><span>Admission Number</span><input type="text" name="admno" value="<?php echo $student_admission ?>"></p>
				<p><span>Choose a Class</span>
					<select name="class" style="padding-left:20px;" required>
						<option value="" > - Choose a Class - </option>
							<?php $as_db_query = "SELECT * FROM as_class ORDER BY class_title ASC";
								$results = $database->get_results( $as_db_query );
								
								foreach( $results as $row ) { ?>
										<option value="<?php echo $row['classid'] ?>">  <?php echo $row['class_title'] ?></option>
								<?php } ?>
						</select></p>                	
				<p style="padding-top: 15px"><span><input type="submit" id="submitBtn" name="SaveOnly" value="Save Only"></span><input type="submit" id="submitBtn" name="SaveClose" value="Save & Close">
			  </p>		
			</form>
			
				
		</div><!--close content_student-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
  </div><!--close main-->
<?php include AS_THEME."as_footer.php" ?>
    
